# Progress log — autonomous build

Read this first when resuming in a new chat or Claude Code session. Each milestone ends with tests green and this file updated.

## Milestone 1 — Import pipeline (FO-27, FO-28, FO-29 partial, FO-33 partial) — IN PROGRESS
Done:
- `app/packages/parsers` — new package: Zerodha tradebook, CAMS/KFintech CAS text, bank CSV (HDFC/ICICI/SBI/Kotak/Axis layouts, auto-detected), Account Aggregator deposit JSON, Form 26AS text, mapping assistant for unknown contract-note layouts, `detect()` / `parseAny()`. 9 tests green against `samples/`.
- `app/apps/api/src/routes/imports.ts` — `POST /imports` (multipart or JSON), detect → parse → apply: instruments resolved/created by ISIN/AMFI/symbol; entities attributed by PAN (last 4) or name; accounts created; `investment_txns` de-duplicated by hash; holdings + FIFO lots maintained; sells consume lots and write `realized_gains` with term; bank statements upsert `bank_txns` with rule-based then keyword categorisation, update balances, and reconcile rent credits to `rent_schedule` (closes the task); 26AS rows into `tds_26as`. `GET /imports`, `GET /imports/:id`, `GET /capital-gains?fy=` (per entity/asset class with exemption from `tax_rules`), `GET /tds/reconciliation?fy=`.
- Security baseline in `server.ts`: helmet headers, rate limit (300/min, 10/min on login), multipart size cap 25 MB, CORS from `CORS_ORIGIN`.
- Type-check clean.
Not yet done (next session, in this order):
1. Run the API suite and add `test/imports.test.ts`: upload each sample; assert holdings/lots/gains/bank rows; second upload is a no-op; unknown layout → 202 needs_mapping → mapping upload succeeds.
2. Web: Investments → Imports tab (upload, job list, mapping dialog) and Capital gains tab; Banking → import button. Mobile: share-sheet upload.
3. `api/openapi.yaml`: confirm `/imports`, `/capital-gains`, `/tds/reconciliation` shapes match; remove those paths from the 501 stubs.
4. Update BUILD-STATUS.md.

## Milestone plan (order of work)
2. Prices & valuations: AMFI NAV + NSE bhavcopy fetchers (worker jobs), `valuations_daily`, XIRR/TWR endpoints, corporate actions (FO-20, 21, 32, 38, 95)
3. Real estate write paths, GST register, property tax, task generators, notifications (phase 3, FO-55/56)
4. Planning & taxation engine + scenarios + optimiser (FO-70..81)
5. Investment Policy builder + compliance (FO-140..147)
6. Rebalancing engine (FO-160..166)
7. GL auto-posting rules + statements + Tally export (FO-47, 62, 63, 110..119)
8. Research pipeline (FO-150..158), then connectors (FO-124..127, 134), documents/MinIO, reports, open data.

## Conventions being followed
See CLAUDE.md. Every milestone: contract → finance/parsers package with tests → route inside withFamily() → integration test → web page → mobile screen → BUILD-STATUS.
