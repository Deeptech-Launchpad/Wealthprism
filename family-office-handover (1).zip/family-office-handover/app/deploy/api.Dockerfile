# API + worker image (context = app/). Full workspace install for reliability; ~250 MB.
FROM node:22-alpine
RUN corepack enable && corepack prepare pnpm@12.4.1 --activate && apk add --no-cache poppler-utils wget
WORKDIR /repo
COPY package.json pnpm-workspace.yaml pnpm-lock.yaml tsconfig.base.json ./
COPY apps/api/package.json apps/api/
COPY apps/web/package.json apps/web/
COPY apps/mobile/package.json apps/mobile/
COPY apps/executor/package.json apps/executor/
COPY packages/finance/package.json packages/finance/
RUN pnpm install --frozen-lockfile --filter @fo/api... --dangerously-allow-all-builds
COPY packages/finance packages/finance
COPY apps/api apps/api
RUN pnpm --filter @fo/finance build && pnpm --filter @fo/api build
ENV NODE_ENV=production
RUN addgroup -S app && adduser -S app -G app && chown -R app:app /repo
USER app
WORKDIR /repo/apps/api
EXPOSE 4000
CMD ["node", "dist/server.js"]
