/**
 * Executor: the only process allowed to submit intents to connectors. Runs as DB role executor_user (read intents/policies,
 * write executions, update intent status). No LLM, no document access. v0 implements the loop, the kill-switch check,
 * idempotent execution records and the SANDBOX adapter; real provider adapters are tickets FO-124..127.
 */
import pg from "pg";
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 2 });
const SANDBOX_ONLY = process.env.SANDBOX_ONLY !== "false";
const ALLOW = (process.env.EGRESS_ALLOWLIST ?? "").split(",").filter(Boolean);

interface Adapter { submit(intent: any, connector: any): Promise<{ provider_ref: string; status: "submitted" | "filled" | "failed"; filled_qty?: number; avg_price?: number; response: any }> }
const sandbox: Adapter = { async submit(intent) { return { provider_ref: `SBX-${intent.id.slice(0, 8)}`, status: "filled", filled_qty: intent.payload.quantity ?? null, avg_price: intent.payload.limit_price ?? null, response: { sandbox: true } }; } };
function adapterFor(connector: any): Adapter {
  if (SANDBOX_ONLY || connector.sandbox) return sandbox;
  throw new Error(`no live adapter for ${connector.provider} yet (FO-124..127); egress allow-list: ${ALLOW.join(",")}`);
}

async function loop() {
  const fams = await pool.query("select id as family_id from families");   // RLS hides intents until the family context is set
  for (const { family_id } of fams.rows) {
    const c = await pool.connect();
    try {
      await c.query("begin"); await c.query("select set_config('app.family_id',$1,true)", [family_id]);
      const ks = await c.query("select paused from kill_switches where family_id=$1", [family_id]);
      if (ks.rows[0]?.paused) { await c.query("rollback"); continue; }
      const q = await c.query("select i.*, (select row_to_json(k) from connectors k where k.id=i.connector_id) as connector from action_intents i where i.status='queued' order by i.created_at limit 5 for update of i skip locked");
      for (const intent of q.rows) {
        if (!intent.connector) { await c.query("update action_intents set status='failed' where id=$1", [intent.id]); console.error("no connector attached", intent.id); continue; }
        const connector = intent.connector;
        const attempt = (await c.query("select coalesce(max(attempt),0)+1 as n from action_executions where intent_id=$1", [intent.id])).rows[0].n;
        await c.query("update action_intents set status='submitted' where id=$1", [intent.id]);
        try {
          const r = await adapterFor(connector).submit(intent, connector);
          await c.query("insert into action_executions (family_id, intent_id, attempt, connector_id, request, response, provider_ref, status, filled_qty, avg_price, completed_at) values ($1,$2,$3,$4,$5,$6,$7,$8::intent_status,$9,$10,now())",
            [family_id, intent.id, attempt, intent.connector_id, JSON.stringify({ kind: intent.kind, payload: intent.payload, idempotency_key: intent.idempotency_key }), JSON.stringify(r.response), r.provider_ref, r.status, r.filled_qty ?? null, r.avg_price ?? null]);
          await c.query("update action_intents set status=$2::intent_status where id=$1", [intent.id, r.status]);
          console.log("executed", intent.id, intent.kind, r.status, r.provider_ref);
        } catch (e: any) {
          await c.query("insert into action_executions (family_id, intent_id, attempt, connector_id, request, status, error, completed_at) values ($1,$2,$3,$4,$5,'failed',$6,now())", [family_id, intent.id, attempt, intent.connector_id, JSON.stringify({ kind: intent.kind }), e.message]);
          await c.query("update action_intents set status='failed' where id=$1", [intent.id]);
          console.error("failed", intent.id, e.message);
        }
      }
      await c.query("commit");
    } catch (e) { await c.query("rollback"); console.error("executor", e); } finally { c.release(); }
  }
}
console.log(`executor started (sandbox_only=${SANDBOX_ONLY}, poll=${process.env.EXECUTOR_POLL_SECONDS ?? 10}s)`);
await loop(); setInterval(() => loop().catch(console.error), Number(process.env.EXECUTOR_POLL_SECONDS ?? 10) * 1000);
