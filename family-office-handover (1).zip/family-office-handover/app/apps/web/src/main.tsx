import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./styles.css";
import { Shell } from "./Shell";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { Investments } from "./pages/Investments";
import { RealEstate } from "./pages/RealEstate";
import { Banking } from "./pages/Banking";
import { Goals } from "./pages/Goals";
import { Tasks } from "./pages/Tasks";
import { Startups } from "./pages/Startups";
import { WorkingCapital } from "./pages/WorkingCapital";
import { ActionPlane } from "./pages/ActionPlane";
import { Books } from "./pages/Books";
import { session } from "./lib/api";
const Guard = ({ children }: { children: React.ReactNode }) => (session.get() ? <>{children}</> : <Navigate to="/login" replace />);
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Guard><Shell /></Guard>}>
          <Route index element={<Dashboard />} />
          <Route path="investments" element={<Investments />} />
          <Route path="real-estate" element={<RealEstate />} />
          <Route path="startups" element={<Startups />} />
          <Route path="goals" element={<Goals />} />
          <Route path="banking" element={<Banking />} />
          <Route path="working-capital" element={<WorkingCapital />} />
          <Route path="tasks" element={<Tasks />} />
          <Route path="action-plane" element={<ActionPlane />} />
          <Route path="books" element={<Books />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
