/** Minimal typed API client shared in spirit with the mobile app: bearer token + X-Family-Id on every call. */
export const API_URL = import.meta.env.VITE_API_URL ?? "/api/v1";
export interface Session { access_token: string; refresh_token: string; user: { id: string; email: string; name: string }; families: { id: string; name: string; role: string }[] }
const KEY = "fo.session", FKEY = "fo.family";
export const session = {
  get: (): Session | null => { try { return JSON.parse(localStorage.getItem(KEY) ?? "null"); } catch { return null; } },
  set: (s: Session | null) => (s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY)),
  family: (): string | null => localStorage.getItem(FKEY) ?? session.get()?.families[0]?.id ?? null,
  setFamily: (id: string) => localStorage.setItem(FKEY, id),
};
export async function login(email: string, password: string): Promise<Session> {
  const r = await fetch(`${API_URL}/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
  if (!r.ok) throw new Error((await r.json()).title ?? "Login failed");
  const s = await r.json(); session.set(s); if (s.families[0]) session.setFamily(s.families[0].id); return s;
}
export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const s = session.get(); const fam = session.family();
  const r = await fetch(`${API_URL}${path}`, { ...init, headers: { "Content-Type": "application/json", ...(s ? { Authorization: `Bearer ${s.access_token}` } : {}), ...(fam ? { "X-Family-Id": fam } : {}), ...(init.headers ?? {}) } });
  if (r.status === 401) { session.set(null); location.href = "/login"; throw new Error("Session expired"); }
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).title ?? `HTTP ${r.status}`);
  return r.json();
}
export const inr = (v: string | number | null | undefined) => { const n = Number(v ?? 0); if (Math.abs(n) >= 1e5) return `₹${(n / 1e5).toFixed(2)} L`; return `₹${n.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`; };
