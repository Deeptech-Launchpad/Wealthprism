import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login } from "../lib/api";
export function Login() {
  const [email, setEmail] = useState("arjun@example.com"); const [pw, setPw] = useState("Prototype!2026"); const [err, setErr] = useState(""); const nav = useNavigate();
  return (
    <div className="login"><form className="card" onSubmit={async (e) => { e.preventDefault(); try { await login(email, pw); nav("/"); } catch (x: any) { setErr(x.message); } }}>
      <div className="brand" style={{ color: "var(--navy)" }}><div className="brand-mark" />Family Office</div>
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" /><input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" />
      {err && <div className="err">{err}</div>}
      <button className="btn btn-p" type="submit">Sign in</button>
      <div className="small mute">Seeded users: arjun / priya / ops / ca @example.com · Prototype!2026</div>
    </form></div>
  );
}
