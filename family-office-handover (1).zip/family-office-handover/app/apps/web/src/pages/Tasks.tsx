import { useState } from "react";
import { useApi } from "../lib/useApi";
import { api, inr } from "../lib/api";
import { Card, Pill, Status, fmtDate } from "../components";
export function Tasks() {
  const [status, setStatus] = useState<"open" | "done">("open");
  const { data, error, loading, refetch } = useApi<any[]>(`/tasks?status=${status}`);
  const [err, setErr] = useState("");
  const move = async (id: string, s: string) => { try { await api(`/tasks/${id}`, { method: "PATCH", body: JSON.stringify({ status: s }) }); refetch(); } catch (e: any) { setErr(e.message); } };
  return (<>
    <div className="tabs">{(["open", "done"] as const).map((s) => <button key={s} className={status === s ? "on" : ""} onClick={() => setStatus(s)}>{s}</button>)}</div>
    {err && <div className="err">{err}</div>}
    {loading || error ? <Status loading={loading} error={error} /> : <Card title={`${data!.length} ${status}`}>{data!.map((t) => <div key={t.id} className="attn"><Pill tone={t.severity === 1 ? "red" : t.severity === 2 ? "amber" : undefined}>{t.module}</Pill><div style={{ flex: 1 }}><b>{t.title}</b><div className="small mute">{t.reason} · {t.entity_name ?? "All"} · due {fmtDate(t.due_date)}{t.amount ? ` · ${inr(t.amount)}` : ""}</div></div>{status === "open" ? <><button className="btn btn-s" onClick={() => move(t.id, "done")}>Done</button><button className="btn btn-s" onClick={() => move(t.id, "dismissed")}>Dismiss</button></> : <button className="btn btn-s" onClick={() => move(t.id, "open")}>Reopen</button>}</div>)}</Card>}
  </>);
}
