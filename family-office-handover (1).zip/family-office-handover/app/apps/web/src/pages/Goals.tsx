import { useApi } from "../lib/useApi";
import { inr } from "../lib/api";
import { Card, Pill, Status } from "../components";
const BC: Record<string, string> = { liquidity: "var(--blue)", income: "var(--teal)", growth: "var(--violet)" };
export function Goals() {
  const g = useApi<any[]>("/goals"); const d = useApi<any[]>("/buckets/drift");
  if (g.loading || g.error) return <Status loading={g.loading} error={g.error} />;
  return (<div className="grid-2">
    <Card title="Goals">{g.data!.map((x) => <div key={x.id} style={{ padding: "10px 0", borderBottom: "1px solid #EFF1F4" }}><div className="row" style={{ justifyContent: "space-between" }}><div><b>{x.name}</b><div className="small mute">{x.target_year} · {x.entity_name} · needs {inr(x.inflated_need)} (today {inr(x.amount_today)})</div></div><Pill tone={x.on_track ? "teal" : "amber"}>{x.bucket}</Pill></div><div className="prog"><div style={{ width: `${x.funded_pct ?? 0}%`, background: BC[x.bucket] }} /></div><div className="small mute">{x.funded_pct ?? 0}% funded · {x.on_track ? "on track" : "behind"}</div></div>)}</Card>
    <Card title="Bucket drift (live)">{d.loading ? "Loading…" : <table className="tbl"><thead><tr><th>Bucket</th><th className="num">Target</th><th className="num">Actual</th><th className="num">Drift</th><th className="num">Value</th></tr></thead><tbody>{(d.data ?? []).map((b) => <tr key={b.bucket}><td style={{ textTransform: "capitalize" }}>{b.bucket}</td><td className="num">{b.targetPct}%</td><td className="num">{b.actualPct}%</td><td className="num"><Pill tone={b.breached ? "amber" : "teal"}>{b.driftPp > 0 ? "+" : ""}{b.driftPp} pp</Pill></td><td className="num">{inr(b.value)}</td></tr>)}</tbody></table>}</Card>
  </div>);
}
