import { useApi } from "../lib/useApi";
import { inr } from "../lib/api";
import { Card, Pill, Status, fmtDate } from "../components";
export function Startups() {
  const { data, error, loading } = useApi<any[]>("/private-investments");
  if (loading || error) return <Status loading={loading} error={error} />;
  return <Card title="Private investments"><table className="tbl"><thead><tr><th>Company</th><th>Stage</th><th>Instrument</th><th>Entity</th><th className="num">Invested</th><th className="num">Mark</th><th className="num">MOIC</th><th className="num">Unfunded</th><th>Status</th></tr></thead><tbody>{data!.map((s) => <tr key={s.id}><td><b>{s.company}</b><div className="small mute">{fmtDate(s.invested_on)} · {s.next_event}</div></td><td>{s.stage}</td><td>{s.instrument}</td><td>{s.entity_name}</td><td className="num">{inr(s.amount)}</td><td className="num">{inr(s.mark)}</td><td className="num">{s.moic}x</td><td className="num">{Number(s.unfunded) ? inr(s.unfunded) : "—"}</td><td><Pill tone={s.status === "active" ? "teal" : s.status === "written_off" ? "red" : "amber"}>{s.status}</Pill></td></tr>)}</tbody></table></Card>;
}
