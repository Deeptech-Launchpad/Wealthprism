import { useState } from "react";
import { useApi } from "../lib/useApi";
import { inr } from "../lib/api";
import { Card, Pill, Status, fmtDate } from "../components";
export function Investments() {
  const [open, setOpen] = useState<string | null>(null);
  const { data, error, loading } = useApi<any>("/holdings");
  const lots = useApi<any[]>(open ? `/holdings/${open}/lots` : null);
  if (loading || error) return <Status loading={loading} error={error} />;
  return (<>
    <Card title="Holdings across entities" action={<span className="small mute">Prices: seeded EOD; unpriced instruments at cost</span>}>
      <table className="tbl"><thead><tr><th>Asset</th><th>Type</th><th>Entity</th><th>Bucket</th><th className="num">Qty</th><th className="num">Cost</th><th className="num">Value</th><th className="num">Gain</th><th className="num">Priced</th></tr></thead>
        <tbody>{data!.items.map((h: any) => <tr key={h.id} onClick={() => setOpen(open === h.id ? null : h.id)} style={{ cursor: "pointer", background: open === h.id ? "var(--paper)" : undefined }}><td><b>{h.instrument}</b></td><td>{h.type}</td><td>{h.entity_name}</td><td><Pill tone={h.bucket === "growth" ? "blue" : h.bucket === "income" ? "teal" : undefined}>{h.bucket}</Pill></td><td className="num">{Number(h.quantity).toLocaleString("en-IN")}</td><td className="num">{inr(h.cost)}</td><td className="num">{inr(h.value)}</td><td className={`num ${Number(h.unrealised_gain) >= 0 ? "up" : "down"}`}>{h.unrealised_gain_pct}%</td><td className="num small mute">{h.price ? fmtDate(h.price_date) : "cost"}</td></tr>)}
          <tr className="total"><td>Total</td><td colSpan={4}></td><td className="num">{inr(data!.totals.cost)}</td><td className="num">{inr(data!.totals.value)}</td><td colSpan={2}></td></tr></tbody></table>
    </Card>
    {open && <Card title="Lots (FIFO order)">{lots.loading ? "Loading…" : <table className="tbl"><thead><tr><th>Buy date</th><th className="num">Qty</th><th className="num">Remaining</th><th className="num">Unit cost</th><th className="num">Charges</th><th>Term now</th></tr></thead><tbody>{(lots.data ?? []).map((l: any) => <tr key={l.id}><td>{fmtDate(l.buy_date)}</td><td className="num">{l.quantity}</td><td className="num">{l.remaining_qty}</td><td className="num">₹{Number(l.unit_cost).toFixed(2)}</td><td className="num">₹{l.charges}</td><td><Pill tone={l.term_now === "long" ? "teal" : "amber"}>{l.term_now}</Pill></td></tr>)}</tbody></table>}</Card>}
  </>);
}
