import { useApi } from "../lib/useApi";
import { inr } from "../lib/api";
import { Card, Pill, Status, fmtDate } from "../components";
export function Banking() {
  const a = useApi<any[]>("/bank-accounts"); const t = useApi<any>("/bank-txns?limit=50");
  if (a.loading || a.error) return <Status loading={a.loading} error={a.error} />;
  return (<>
    <Card title="Accounts">{a.data!.map((x) => <div key={x.id} className="attn"><div style={{ flex: 1 }}><b>{x.bank} {x.account_masked}</b><div className="small mute">{x.type} · {x.entity_name}</div></div><div className="num" style={{ color: Number(x.balance) < 0 ? "var(--red)" : undefined }}>{inr(x.balance)}</div><Pill tone={x.sync_mode === "aa" ? "teal" : undefined}>{x.sync_mode === "aa" ? `AA · ${fmtDate(x.balance_as_of)}` : x.sync_mode}</Pill></div>)}</Card>
    <Card title="Transactions">{t.loading ? "Loading…" : <table className="tbl"><thead><tr><th>Date</th><th>Narration</th><th>Category</th><th>Account</th><th className="num">Amount</th></tr></thead><tbody>{(t.data?.items ?? []).map((x: any) => <tr key={x.id}><td>{fmtDate(x.txn_date)}</td><td>{x.narration}</td><td><Pill tone={Number(x.amount) > 0 ? "teal" : undefined}>{x.category ?? "—"}</Pill>{x.link_type !== "none" && <span className="small mute"> · {x.link_type}</span>}</td><td className="mute small">{x.account_label}</td><td className={`num ${Number(x.amount) > 0 ? "up" : ""}`}>{Number(x.amount) > 0 ? "+" : "−"}{inr(Math.abs(Number(x.amount)))}</td></tr>)}</tbody></table>}</Card>
  </>);
}
