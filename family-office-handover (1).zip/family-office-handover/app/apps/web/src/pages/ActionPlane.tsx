import { useState } from "react";
import { useApi } from "../lib/useApi";
import { api, inr } from "../lib/api";
import { Card, Pill, Status } from "../components";
const tone = (s: string) => s === "pending_approval" ? "amber" : s === "policy_failed" || s === "failed" || s === "rejected" ? "red" : s === "approved" || s === "queued" || s === "submitted" ? "blue" : s === "filled" || s === "reconciled" || s === "posted" ? "teal" : undefined;
export function ActionPlane() {
  const [tab, setTab] = useState<"pending" | "all" | "oversight">("pending");
  const list = useApi<any>(tab === "pending" ? "/actions?status=pending_approval" : "/actions");
  const ov = useApi<any>("/oversight");
  const [proof, setProof] = useState("000000"); const [err, setErr] = useState("");
  const [form, setForm] = useState({ entity_id: "", kind: "mf_purchase", amount: "7000", rationale: "" });
  const entities = useApi<any[]>("/entities");
  const act = async (id: string, what: "approve" | "reject") => { setErr(""); try { await api(`/actions/${id}/${what}`, { method: "POST", body: JSON.stringify(what === "approve" ? { auth_method: "totp", auth_proof: proof } : {}) }); list.refetch(); ov.refetch(); } catch (e: any) { setErr(e.message); } };
  const propose = async () => { setErr(""); try { await api("/actions", { method: "POST", body: JSON.stringify({ entity_id: form.entity_id || entities.data?.[0]?.id, kind: form.kind, amount: Number(form.amount), payload: { note: "proposed from web" }, rationale: form.rationale }) }); list.refetch(); ov.refetch(); } catch (e: any) { setErr(e.message); } };
  return (<>
    <div className="tabs">{(["pending", "all", "oversight"] as const).map((t) => <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>{t}</button>)}</div>
    {err && <div className="err">{err}</div>}
    {tab === "oversight" ? (ov.data ? <div className="grid-2">
      <Card title="Kill switch"><div className="row gap"><Pill tone={ov.data.kill_switch.paused ? "red" : "teal"}>{ov.data.kill_switch.paused ? `paused · ${ov.data.kill_switch.reason ?? ""}` : "running"}</Pill><button className="btn btn-s" onClick={() => api("/kill-switch", { method: "POST", body: JSON.stringify({ paused: !ov.data.kill_switch.paused, reason: "from web" }) }).then(ov.refetch).catch((e) => setErr(e.message))}>{ov.data.kill_switch.paused ? "Resume (owner)" : "Pause all"}</button></div><div className="small mute" style={{ marginTop: 8 }}>Pending {ov.data.pending.length} · in flight {ov.data.in_flight.length} · failed 24 h {ov.data.failed_24h.length}</div></Card>
      <Card title="Connectors">{ov.data.connectors.map((c: any) => <div key={c.id} className="attn"><span style={{ flex: 1 }}>{c.label} <span className="mute small">{c.provider}</span></span><Pill tone={c.status === "active" ? "teal" : "amber"}>{c.status}</Pill></div>)}{!ov.data.connectors.length && <span className="small mute">None yet — an assisted/sandbox connector is created on the first intent.</span>}</Card>
    </div> : <Status loading={ov.loading} error={ov.error} />) : (<>
      <Card title="Propose an intent (operator or owner)" action={<span className="small mute">Policy checks and four-eyes apply</span>}>
        <div className="row gap" style={{ flexWrap: "wrap" }}>
          <select className="entity" style={{ background: "#fff", color: "var(--ink)", borderColor: "var(--line)" }} value={form.entity_id} onChange={(e) => setForm({ ...form, entity_id: e.target.value })}>{(entities.data ?? []).map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
          <select className="entity" style={{ background: "#fff", color: "var(--ink)", borderColor: "var(--line)" }} value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>{["mf_purchase", "mf_redemption", "equity_order", "bank_transfer", "bill_payment", "assisted"].map((k) => <option key={k}>{k}</option>)}</select>
          <input className="entity" style={{ background: "#fff", color: "var(--ink)", borderColor: "var(--line)", width: 120 }} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          <input className="entity" style={{ background: "#fff", color: "var(--ink)", borderColor: "var(--line)", flex: 1 }} placeholder="Rationale" value={form.rationale} onChange={(e) => setForm({ ...form, rationale: e.target.value })} />
          <button className="btn btn-p" onClick={propose}>Propose</button>
        </div>
      </Card>
      {list.loading || list.error ? <Status loading={list.loading} error={list.error} /> : <Card title={`${list.data.items.length} intents`} action={<span className="row gap small mute">Step-up code <input className="entity" style={{ background: "#fff", color: "var(--ink)", borderColor: "var(--line)", width: 90 }} value={proof} onChange={(e) => setProof(e.target.value)} /></span>}>
        {list.data.items.map((i: any) => <div key={i.id} className="attn"><Pill tone={tone(i.status)}>{i.status}</Pill><div style={{ flex: 1 }}><b>{i.kind}</b> · {inr(i.amount)} · {i.entity_name}<div className="small mute">by {i.proposed_by_name ?? i.proposed_by_kind} · {i.rationale ?? ""} · approvals {(i.approvals ?? []).filter((a: any) => a.decision === "approved").length}/{i.approvers_required} · {(i.policy_result ?? []).filter((p: any) => !p.pass).map((p: any) => p.code + " ✗").join(", ") || "policy pass"}</div></div>{i.status === "pending_approval" && <><button className="btn btn-s btn-p" onClick={() => act(i.id, "approve")}>Approve</button><button className="btn btn-s" onClick={() => act(i.id, "reject")}>Reject</button></>}</div>)}
        <div className="small mute" style={{ marginTop: 10 }}>Dev step-up code is 000000 (NODE_ENV ≠ production); TOTP against the user's MFA secret otherwise. The proposer can never approve; approvals queue the intent for the executor, which runs in sandbox until SANDBOX_ONLY is turned off per connector.</div>
      </Card>}
    </>)}
  </>);
}
