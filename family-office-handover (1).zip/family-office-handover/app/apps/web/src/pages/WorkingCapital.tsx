import { useApi } from "../lib/useApi";
import { inr } from "../lib/api";
import { Card, Status } from "../components";
export function WorkingCapital() {
  const { data, error, loading } = useApi<any>("/working-capital/summary");
  if (loading || error) return <Status loading={loading} error={error} />;
  const d = data!;
  return (<>
    <div className="kpis">
      <Card><div className="mute">Cash across accounts</div><div className="big-num">{inr(d.cash_total)}</div></Card>
      <Card><div className="mute">Required float ({d.float_days} days)</div><div className="big-num">{inr(d.required_float)}</div><div className="small mute">{d.committed_outflows} committed outflows + buffer</div></Card>
      <Card><div className="mute">Deployable excess</div><div className="big-num" style={{ color: "var(--teal)" }}>{inr(d.deployable_excess)}</div></Card>
      <Card><div className="mute">Drag from idle cash</div><div className="big-num" style={{ color: "var(--red)" }}>{inr(d.drag_per_year)} / yr</div><div className="small mute">vs arbitrage after tax</div></Card>
    </div>
    <Card title="Next"><div className="small mute">Deployment ladder, committed-outflow list and intent creation land with tickets FO-60 and FO-121; the float and excess above are computed live by @fo/finance from the seeded bank balances and outflows.</div></Card>
  </>);
}
