import { useApi } from "../lib/useApi";
import { inr } from "../lib/api";
import { Card, Pill, Status, fmtDate } from "../components";
const month = new Date().toISOString().slice(0, 7);
export function RealEstate() {
  const p = useApi<any[]>("/properties"); const r = useApi<any[]>(`/rent-schedule?month=${month}`);
  if (p.loading || p.error) return <Status loading={p.loading} error={p.error} />;
  return (<>
    <Card title="Properties">{p.data!.map((x) => <div key={x.id} className="attn"><div style={{ flex: 1 }}><b>{x.name}</b><div className="small mute">{x.type} · {x.owners?.map((o: any) => `${o.name} ${o.ownership_pct}%`).join(", ")}{x.active_lease ? ` · Tenant: ${x.active_lease.tenant} · lease to ${fmtDate(x.active_lease.end_date)}` : " · vacant"}</div></div><div className="num"><div className="mute small">Value</div>{inr(x.current_value)}</div><div className="num"><div className="mute small">Rent</div>{x.active_lease ? inr(x.active_lease.rent) : "—"}</div><div className="num"><div className="mute small">Yield</div>{x.gross_yield_pct ?? "—"}%</div>{x.active_lease?.gst_applicable ? <Pill tone="blue">GST 18%</Pill> : <Pill>No GST</Pill>}</div>)}</Card>
    <Card title={`Rent schedule — ${month}`}>{r.loading ? "Loading…" : <table className="tbl"><thead><tr><th>Due</th><th>Property</th><th>Tenant</th><th className="num">Rent</th><th className="num">GST</th><th className="num">TDS</th><th className="num">Received</th><th>Status</th></tr></thead><tbody>{(r.data ?? []).map((x) => <tr key={x.id}><td>{fmtDate(x.due_date)}</td><td>{x.property}</td><td>{x.tenant}</td><td className="num">{inr(x.expected_rent)}</td><td className="num">{Number(x.expected_gst) ? inr(x.expected_gst) : "—"}</td><td className="num">{Number(x.expected_tds) ? inr(x.expected_tds) : "—"}</td><td className="num">{inr(x.received_amount)}</td><td><Pill tone={x.status === "received" ? "teal" : x.status === "overdue" ? "red" : "amber"}>{x.status}{x.status === "overdue" ? ` ${x.overdue_days} d` : ""}</Pill></td></tr>)}</tbody></table>}</Card>
  </>);
}
