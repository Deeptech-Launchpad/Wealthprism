import { useState } from "react";
import { useApi } from "../lib/useApi";
import { api, inr } from "../lib/api";
import { Card, Pill, Status, fmtDate } from "../components";
const FY = "2026-27";
export function Books() {
  const ents = useApi<any[]>("/entities"); const books = useApi<any[]>("/gl/books");
  const [ent, setEnt] = useState<string>(""); const [tab, setTab] = useState<"tb" | "journals" | "periods">("tb"); const [err, setErr] = useState("");
  const entity = ent || books.data?.[0]?.entity_id || "";
  const tb = useApi<any[]>(entity ? `/gl/reports/trial-balance?entity_id=${entity}&fy=${FY}` : null);
  const jn = useApi<any>(entity ? `/gl/journals?entity_id=${entity}&fy=${FY}` : null);
  const pr = useApi<any[]>(entity ? `/gl/periods?entity_id=${entity}` : null);
  const open = async (entity_id: string) => { setErr(""); try { await api("/gl/books", { method: "PUT", body: JSON.stringify({ entity_id, books_start_date: "2026-04-01" }) }); books.refetch(); setEnt(entity_id); } catch (e: any) { setErr(e.message); } };
  const dr = (tb.data ?? []).reduce((s, r) => s + Number(r.debit), 0), cr = (tb.data ?? []).reduce((s, r) => s + Number(r.credit), 0);
  return (<>
    <Card title="Books" action={<span className="small mute">One book per entity · accrual · FY starts April</span>}>
      <div className="row gap" style={{ flexWrap: "wrap" }}>{(ents.data ?? []).map((e) => { const b = books.data?.find((x) => x.entity_id === e.id); return b ? <button key={e.id} className={`btn btn-s ${entity === e.id ? "btn-p" : ""}`} onClick={() => setEnt(e.id)}>{e.name}</button> : <button key={e.id} className="btn btn-s" onClick={() => open(e.id)}>Open books: {e.name}</button>; })}</div>
      {err && <div className="err" style={{ marginTop: 8 }}>{err}</div>}
    </Card>
    {entity && <>
      <div className="tabs">{(["tb", "journals", "periods"] as const).map((t) => <button key={t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>{t === "tb" ? "Trial balance" : t === "journals" ? "Day book" : "Periods"}</button>)}</div>
      {tab === "tb" && (tb.data ? <Card title={`Trial balance — FY ${FY}`} action={<Pill tone={Math.abs(dr - cr) < 0.01 ? "teal" : "red"}>{Math.abs(dr - cr) < 0.01 ? "balanced" : "unbalanced"}</Pill>}><table className="tbl"><thead><tr><th>Code</th><th>Account</th><th>Type</th><th className="num">Debit</th><th className="num">Credit</th><th className="num">Closing</th></tr></thead><tbody>{tb.data.map((r) => <tr key={r.code}><td className="mute">{r.code}</td><td>{r.name}</td><td><Pill>{r.type}</Pill></td><td className="num">{Number(r.debit) ? inr(r.debit) : "—"}</td><td className="num">{Number(r.credit) ? inr(r.credit) : "—"}</td><td className="num">{inr(r.closing)}</td></tr>)}<tr className="total"><td></td><td>Total</td><td></td><td className="num">{inr(dr)}</td><td className="num">{inr(cr)}</td><td></td></tr></tbody></table>{!tb.data.length && <div className="small mute">No postings yet — auto-posting from imports lands with FO-47/62/63; manual journals via POST /gl/journals.</div>}</Card> : <Status loading={tb.loading} error={tb.error} />)}
      {tab === "journals" && (jn.data ? <Card title="Day book">{jn.data.items.map((j: any) => <div key={j.id} style={{ padding: "10px 0", borderBottom: "1px solid #EFF1F4" }}><div className="row" style={{ justifyContent: "space-between" }}><b>#{j.journal_no} · {j.narration}</b><span className="row gap"><Pill tone={j.source === "auto" ? "teal" : "blue"}>{j.source}</Pill><Pill tone={j.status === "posted" ? "teal" : "amber"}>{j.status}</Pill><span className="small mute">{fmtDate(j.entry_date)}</span></span></div><table className="tbl" style={{ marginTop: 6 }}><tbody>{(j.lines ?? []).map((l: any) => <tr key={l.line_no}><td className="mute">{l.account_code}</td><td>{l.account_name}</td><td className="num">{Number(l.debit) ? inr(l.debit) : ""}</td><td className="num">{Number(l.credit) ? inr(l.credit) : ""}</td></tr>)}</tbody></table></div>)}{!jn.data.items.length && <div className="small mute">No journals in this FY.</div>}</Card> : <Status loading={jn.loading} error={jn.error} />)}
      {tab === "periods" && (pr.data ? <Card title="Periods">{pr.data.map((p) => <div key={p.id} className="attn"><span style={{ flex: 1 }}>FY {p.fy} · {fmtDate(p.period_start)} – {fmtDate(p.period_end)}</span><Pill tone={p.status === "locked" ? "teal" : p.status === "soft_closed" ? "amber" : undefined}>{p.status}</Pill><button className="btn btn-s" onClick={() => api(`/gl/periods/${p.id}/status`, { method: "POST", body: JSON.stringify({ status: p.status === "locked" ? "open" : "locked" }) }).then(pr.refetch).catch((e) => setErr(e.message))}>{p.status === "locked" ? "Reopen" : "Lock"}</button></div>)}</Card> : <Status loading={pr.loading} error={pr.error} />)}
    </>}
  </>);
}
