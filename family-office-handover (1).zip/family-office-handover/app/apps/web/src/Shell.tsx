import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { LayoutDashboard, TrendingUp, Building2, Rocket, Target, Landmark, Droplets, ClipboardCheck, LogOut, Zap, BookOpen } from "lucide-react";
import { session } from "./lib/api";
const NAV = [["/", "Dashboard", LayoutDashboard], ["/investments", "Investments", TrendingUp], ["/real-estate", "Real estate", Building2], ["/startups", "Startups", Rocket], ["/goals", "Goals & buckets", Target], ["/banking", "Banking", Landmark], ["/working-capital", "Working capital", Droplets], ["/tasks", "Tasks", ClipboardCheck], ["/action-plane", "Action plane", Zap], ["/books", "Books", BookOpen]] as const;
export function Shell() {
  const s = session.get()!; const loc = useLocation(); const nav = useNavigate();
  const title = NAV.find(([p]) => p === loc.pathname)?.[1] ?? "Family Office";
  return (
    <div className="app">
      <aside className="rail">
        <div className="brand"><div className="brand-mark" />Family Office</div>
        <select className="entity" value={session.family() ?? ""} onChange={(e) => { session.setFamily(e.target.value); location.reload(); }}>{s.families.map((f) => <option key={f.id} value={f.id}>{f.name} · {f.role}</option>)}</select>
        <nav>{NAV.map(([p, n, I]) => <NavLink key={p} to={p} end={p === "/"}><I size={16} />{n}</NavLink>)}</nav>
        <div className="rail-foot">{s.user.name}<br /><button className="btn btn-s" style={{ marginTop: 8 }} onClick={() => { session.set(null); nav("/login"); }}><LogOut size={13} /> Sign out</button></div>
      </aside>
      <main><header className="top"><h1>{title}</h1><span className="small mute">Live from API · {new Date().toLocaleDateString("en-IN")}</span></header><div className="content"><Outlet /></div></main>
    </div>
  );
}
