import React from "react";
import { View, Text } from "react-native";
import { session } from "../lib/api";
import { Screen, Card, Btn, s } from "../ui";
export function MoreScreen({ onSignOut }: { onSignOut: () => void }) {
  const u = session.get()!;
  return (
    <Screen>
      <Card title="Account"><Text style={s.body}>{u.user.name}</Text><Text style={s.mute}>{u.user.email}</Text><View style={{ marginTop: 10 }}><Btn title="Sign out" onPress={() => session.set(null).then(onSignOut)} /></View></Card>
      <Card title="Family">{u.families.map((f) => <View key={f.id} style={[s.between, s.line]}><Text style={s.body}>{f.name}</Text><Text style={s.mute}>{f.role}{session.family() === f.id ? " · active" : ""}</Text></View>)}</Card>
      <Card title="Coming with the build phases"><Text style={s.mute}>Goals & buckets · Planning & tax · Investment policy · Rebalancing · Research digest · Books · Action-plane approvals with biometric step-up · Banking · Working capital · Reports. Screens follow the same pattern as Dashboard and Tasks; every one reads the shared API contract in api/openapi.yaml.</Text></Card>
    </Screen>
  );
}
