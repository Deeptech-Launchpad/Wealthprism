import React from "react";
import { View, Text } from "react-native";
import { useApi } from "../lib/useApi";
import { inr, fmtDate } from "../lib/api";
import { Screen, Card, Pill, Status, s, C } from "../ui";
const BC: Record<string, string> = { liquidity: C.blue, income: C.teal, growth: C.violet };
export function DashboardScreen() {
  const { data, error, loading, refetch } = useApi<any>("/dashboard");
  if (!data) return <Screen><Status loading={loading} error={error} /></Screen>;
  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <Card><Text style={s.mute}>Consolidated net worth</Text><Text style={s.hero}>{inr(data.net_worth)}</Text><Text style={s.mute}>{data.by_entity.length} entities · holdings, property, private, cash</Text></Card>
      <View style={[s.row, { gap: 12 }]}>
        <View style={[s.card, { flex: 1 }]}><Text style={s.mute}>Bank balances</Text><Text style={s.big}>{inr(data.bank_balance_total)}</Text><Text style={s.mute}>{data.bank_accounts_live}/{data.bank_accounts_total} live</Text></View>
        <View style={[s.card, { flex: 1 }]}><Text style={s.mute}>Rent this month</Text><Text style={s.big}>{inr(data.rent.due)}</Text><Text style={{ color: data.rent.overdue_count ? C.red : C.mute, fontSize: 12 }}>{data.rent.overdue_count} overdue</Text></View>
      </View>
      <Card title="Three-bucket strategy">
        <View style={{ flexDirection: "row", height: 30, borderRadius: 6, overflow: "hidden", gap: 2 }}>{data.buckets.map((b: any) => <View key={b.bucket} style={{ flex: b.actualPct, backgroundColor: BC[b.bucket], justifyContent: "center", paddingHorizontal: 6 }}><Text style={{ color: "#fff", fontSize: 11 }} numberOfLines={1}>{b.actualPct}%</Text></View>)}</View>
        {data.buckets.map((b: any) => <View key={b.bucket} style={[s.between, s.line]}><Text style={[s.body, { textTransform: "capitalize" }]}>{b.bucket} <Text style={s.mute}>target {b.targetPct}%</Text></Text><Pill tone={b.breached ? "amber" : "teal"}>{b.driftPp > 0 ? "+" : ""}{b.driftPp} pp</Pill></View>)}
      </Card>
      <Card title="By entity">{data.by_entity.map((e: any) => <View key={e.entity_id} style={[s.between, s.line]}><Text style={s.body}>{e.name}</Text><Text style={s.num}>{inr(e.net_worth)}</Text></View>)}</Card>
      <Card title="Needs attention">{data.attention.map((t: any) => <View key={t.id} style={s.line}><View style={s.row}><Pill tone={t.severity === 1 ? "red" : t.severity === 2 ? "amber" : undefined}>{t.module}</Pill><Text style={s.mute}>{fmtDate(t.due_date)}</Text></View><Text style={[s.body, { marginTop: 4 }]}>{t.title}</Text></View>)}</Card>
    </Screen>
  );
}
