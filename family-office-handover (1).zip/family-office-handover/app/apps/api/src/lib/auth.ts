import { createHmac } from "node:crypto";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import type { FastifyReply, FastifyRequest } from "fastify";
import { pool } from "./db.js";
import { config } from "../config.js";
export interface AuthUser { id: string; email: string; name: string }
export interface FamilyCtx { familyId: string; role: "owner" | "member" | "operator" | "viewer"; entityScope: string[] | null }
declare module "fastify" { interface FastifyRequest { user?: AuthUser; family?: FamilyCtx } }
export async function verifyPassword(email: string, password: string): Promise<AuthUser | null> {
  const { rows } = await pool.query("select id, email, name, password_hash from users where email = $1", [email]);
  if (!rows[0]) return null;
  const ok = await bcrypt.compare(password, rows[0].password_hash);
  return ok ? { id: rows[0].id, email: rows[0].email, name: rows[0].name } : null;
}
export function issueTokens(u: AuthUser) {
  const access = jwt.sign({ sub: u.id, email: u.email, name: u.name }, config.jwtSecret, { expiresIn: config.accessTtl });
  const refresh = jwt.sign({ sub: u.id, typ: "refresh" }, config.refreshSecret, { expiresIn: config.refreshTtl });
  return { access_token: access, refresh_token: refresh, expires_in: 900 };
}
export async function familiesFor(userId: string) {
  const { rows } = await pool.query("select id, name, role from user_families($1)", [userId]);
  return rows;
}
/** preHandler: requires Bearer token and X-Family-Id; loads the membership (role + entity scope). */
export async function requireFamily(req: FastifyRequest, reply: FastifyReply) {
  const h = req.headers.authorization ?? "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return reply.code(401).send({ title: "Unauthenticated", status: 401 });
  let payload: any;
  try { payload = jwt.verify(token, config.jwtSecret); } catch { return reply.code(401).send({ title: "Invalid token", status: 401 }); }
  req.user = { id: payload.sub, email: payload.email, name: payload.name };
  const familyId = req.headers["x-family-id"];
  if (typeof familyId !== "string") return reply.code(400).send({ title: "X-Family-Id header required", status: 400 });
  const { rows } = await pool.query("select role, entity_scope from user_families($2) where id = $1", [familyId, req.user.id]);
  if (!rows[0]) return reply.code(403).send({ title: "Not a member of this family", status: 403 });
  req.family = { familyId, role: rows[0].role, entityScope: rows[0].entity_scope };
}
export function requireRole(...roles: FamilyCtx["role"][]) {
  return async (req: FastifyRequest, reply: FastifyReply) => {
    if (!req.family || !roles.includes(req.family.role)) return reply.code(403).send({ title: "Insufficient role", status: 403 });
  };
}
/** RFC 6238 TOTP (SHA-1, 30 s, 6 digits) for step-up authentication. Secret is base32. */
export function totp(secretB32: string, at = Date.now()): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; let bits = ""; for (const ch of secretB32.replace(/=+$/, "").toUpperCase()) bits += alphabet.indexOf(ch).toString(2).padStart(5, "0");
  const key = Buffer.from(bits.match(/.{8}/g)!.map((b) => parseInt(b, 2)));
  const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(Math.floor(at / 30000)));
  const h = createHmac("sha1", key).update(counter).digest(); const o = h[h.length - 1] & 0xf;
  return String(((h.readUInt32BE(o) & 0x7fffffff) % 1_000_000)).padStart(6, "0");
}
/** Step-up check used by approvals and signatures. Dev bypass: proof "000000" when NODE_ENV !== production. */
export async function verifyStepUp(userId: string, method: string, proof: string): Promise<boolean> {
  if (process.env.NODE_ENV !== "production" && proof === "000000") return true;
  if (method === "totp") { const u = (await pool.query("select mfa_secret from users where id = $1", [userId])).rows[0]; return !!u?.mfa_secret && totp(u.mfa_secret) === proof; }
  return false;   // biometric/passkey assertions are verified against registered device keys in FO-122
}
