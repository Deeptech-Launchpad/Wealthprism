import pg from "pg";
import { config } from "../config.js";
export const pool = new pg.Pool({ connectionString: config.databaseUrl, max: 10 });
/** Run `fn` inside a transaction with app.family_id set so Postgres RLS scopes every query. */
export async function withFamily<T>(familyId: string, fn: (c: pg.PoolClient) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query("begin");
    await c.query("select set_config('app.family_id', $1, true)", [familyId]);
    const r = await fn(c);
    await c.query("commit");
    return r;
  } catch (e) { await c.query("rollback"); throw e; } finally { c.release(); }
}
export const money = (v: unknown) => (v === null || v === undefined ? "0.00" : Number(v).toFixed(2));
