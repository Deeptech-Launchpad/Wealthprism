/** Scheduler: releases approved intents after cooling-off, expires stale ones, refreshes GL balances, flags overdue rent. Runs every 60 s. */
import { pool } from "./lib/db.js";
async function tick() {
  await pool.query(`update action_intents set status='expired' where status in ('pending_approval','approved') and expires_at < now()`);
  const fams = await pool.query("select id from families");
  for (const f of fams.rows) {
    const c = await pool.connect();
    try {
      await c.query("begin"); await c.query("select set_config('app.family_id',$1,true)", [f.id]);
      const due = await c.query("select id from action_intents where status='approved' and (cooling_off_until is null or cooling_off_until <= now())");
      for (const i of due.rows) { await c.query("savepoint s"); try { await c.query("update action_intents set status='queued' where id=$1", [i.id]); await c.query("release savepoint s"); } catch { await c.query("rollback to savepoint s"); } }
      await c.query(`update rent_schedule set status='overdue' where status='due' and due_date + (select grace_days from leases l where l.id=rent_schedule.lease_id) < current_date`);
      await c.query(`insert into tasks (family_id, entity_id, module, title, reason, amount, due_date, severity, source_type, source_id)
        select rs.family_id, po.entity_id, 'real_estate', 'Rent overdue: ' || p.name, 'Due ' || rs.due_date || ', tenant ' || t.name, rs.expected_rent - rs.received_amount, current_date, 1, 'rent_schedule', rs.id
        from rent_schedule rs join leases l on l.id=rs.lease_id join properties p on p.id=l.property_id join tenants t on t.id=l.tenant_id join property_owners po on po.property_id=p.id
        where rs.status='overdue' and not exists (select 1 from tasks x where x.source_type='rent_schedule' and x.source_id=rs.id and x.status='open')`);
      await c.query("commit");
    } catch (e) { await c.query("rollback"); console.error("worker", f.id, e); } finally { c.release(); }
  }
  await pool.query("refresh materialized view concurrently gl_balances").catch(() => pool.query("refresh materialized view gl_balances").catch(() => {}));
}
console.log("worker started"); await tick(); setInterval(() => tick().catch(console.error), Number(process.env.WORKER_INTERVAL_MS ?? 60000));
