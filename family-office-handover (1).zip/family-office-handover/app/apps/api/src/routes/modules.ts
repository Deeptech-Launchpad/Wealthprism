import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { withFamily, money } from "../lib/db.js";
import { requireFamily, requireRole, verifyStepUp } from "../lib/auth.js";

/** Planning, GL, action plane, investment policy, research, rebalancing — read paths and the safety-critical write paths. */
export default async function routes(app: FastifyInstance) {
  app.addHook("preHandler", requireFamily);
  // ---- planning & tax ----
  app.get("/plans", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query(`select p.*, (select row_to_json(r) from (select summary, allocation_after, goals_after, warnings, computed_at from plan_results r where r.scenario_id=p.id order by computed_at desc limit 1) r) as latest_result,
      (select count(*) from plan_actions a where a.scenario_id=p.id) as action_count, (select count(*) from plan_actions a where a.scenario_id=p.id and a.status='done') as actions_done from plan_scenarios p where deleted_at is null order by is_baseline desc, created_at`)).rows));
  app.get("/plans/:id", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { id } = req.params as any;
    const p = (await c.query("select * from plan_scenarios where id=$1", [id])).rows[0]; if (!p) return { title: "Not found", status: 404 };
    p.actions = (await c.query("select * from plan_actions where scenario_id=$1 order by seq", [id])).rows;
    p.comments = (await c.query("select pc.*, u.name as user_name from plan_comments pc join users u on u.id=pc.user_id where scenario_id=$1 order by created_at", [id])).rows;
    p.results = (await c.query("select * from plan_results where scenario_id=$1 order by computed_at desc limit 3", [id])).rows;
    return p;
  }));
  app.get("/tax/suggestions", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select s.*, e.name as entity_name from tax_suggestions s left join entities e on e.id=s.entity_id where status=coalesce($1::suggestion_status,'new') order by est_saving desc nulls last", [(req.query as any).status ?? null])).rows));

  // ---- general ledger ----
  app.get("/gl/books", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select b.*, e.name as entity_name from gl_books b join entities e on e.id=b.entity_id")).rows));
  app.put("/gl/books", { preHandler: requireRole("owner", "operator") }, async (req) => withFamily(req.family!.familyId, async (c) => {
    const b = z.object({ entity_id: z.string().uuid(), basis: z.enum(["accrual", "cash"]).default("accrual"), books_start_date: z.string(), mark_to_market: z.boolean().default(false), maker_checker: z.boolean().default(false) }).parse(req.body);
    await c.query("insert into gl_books (entity_id, family_id, basis, books_start_date, mark_to_market, maker_checker) values ($1,$2,$3,$4,$5,$6) on conflict (entity_id) do update set basis=$3, mark_to_market=$5, maker_checker=$6", [b.entity_id, req.family!.familyId, b.basis, b.books_start_date, b.mark_to_market, b.maker_checker]);
    // copy CoA template if the book has no accounts yet
    await c.query(`insert into gl_accounts (family_id, entity_id, code, name, type, parent_code, is_group, is_system, tax_head, tally_parent_group)
      select $1, $2, code, name, type, parent_code, is_group, is_system, tax_head, tally_parent_group from gl_accounts t where t.family_id is null
      and not exists (select 1 from gl_accounts x where x.entity_id=$2 and x.code=t.code)`, [req.family!.familyId, b.entity_id]);
    const fyStart = new Date(b.books_start_date); const y = fyStart.getMonth() >= 3 ? fyStart.getFullYear() : fyStart.getFullYear() - 1;
    await c.query("insert into gl_periods (family_id, entity_id, fy, period_start, period_end) values ($1,$2,$3,$4,$5) on conflict do nothing", [req.family!.familyId, b.entity_id, `${y}-${String((y + 1) % 100).padStart(2, "0")}`, `${y}-04-01`, `${y + 1}-03-31`]);
    return (await c.query("select * from gl_books where entity_id=$1", [b.entity_id])).rows[0];
  }));
  app.get("/gl/accounts", async (req) => withFamily(req.family!.familyId, async (c) => {
    const q = req.query as any;
    return (await c.query(`select a.id, a.code, a.name, a.type, a.parent_code, a.is_group, a.is_system, a.tax_head, a.tally_parent_group, a.active,
      coalesce((select sum(l.debit)-sum(l.credit) from gl_lines l join gl_journals j on j.id=l.journal_id where l.account_id=a.id and j.status='posted' and ($2::text is null or j.fy=$2)),0) as balance
      from gl_accounts a where a.entity_id=$1 order by a.code`, [q.entity_id, q.fy ?? null])).rows;
  }));
  app.get("/gl/reports/trial-balance", async (req) => withFamily(req.family!.familyId, async (c) => {
    const q = req.query as any;
    return (await c.query(`select a.code, a.name, a.type, coalesce(sum(l.debit),0) as debit, coalesce(sum(l.credit),0) as credit, coalesce(sum(l.debit)-sum(l.credit),0) as closing
      from gl_accounts a left join gl_lines l on l.account_id=a.id left join gl_journals j on j.id=l.journal_id and j.status='posted' and j.fy=$2
      where a.entity_id=$1 and not a.is_group group by a.code, a.name, a.type having coalesce(sum(l.debit),0)<>0 or coalesce(sum(l.credit),0)<>0 order by a.code`, [q.entity_id, q.fy])).rows;
  }));
  app.get("/gl/journals", async (req) => withFamily(req.family!.familyId, async (c) => {
    const q = req.query as any;
    const r = await c.query(`select j.*, (select json_agg(json_build_object('line_no', l.line_no, 'account_id', l.account_id, 'account_code', a.code, 'account_name', a.name, 'debit', l.debit, 'credit', l.credit, 'narration', l.narration) order by l.line_no) from gl_lines l join gl_accounts a on a.id=l.account_id where l.journal_id=j.id) as lines
      from gl_journals j where j.entity_id=$1 and ($2::text is null or j.fy=$2) order by j.entry_date desc, j.journal_no desc limit 200`, [q.entity_id, q.fy ?? null]);
    return { items: r.rows, next_cursor: null };
  }));
  app.post("/gl/journals", { preHandler: requireRole("owner", "operator") }, async (req, reply) => withFamily(req.family!.familyId, async (c) => {
    const b = z.object({ entity_id: z.string().uuid(), entry_date: z.string(), narration: z.string().min(1), lines: z.array(z.object({ account_id: z.string().uuid(), debit: z.coerce.number().default(0), credit: z.coerce.number().default(0), narration: z.string().optional(), sub_ledger_type: z.string().optional(), sub_ledger_id: z.string().uuid().optional() })).min(2) }).parse(req.body);
    const fy = fyOf(b.entry_date);
    const no = (await c.query("select coalesce(max(journal_no),0)+1 as n from gl_journals where entity_id=$1 and fy=$2", [b.entity_id, fy])).rows[0].n;
    const j = (await c.query("insert into gl_journals (family_id, entity_id, journal_no, fy, entry_date, source, source_type, source_id, narration, posted_by) values ($1,$2,$3,$4,$5,'manual','manual',gen_random_uuid(),$6,$7) returning *", [req.family!.familyId, b.entity_id, no, fy, b.entry_date, b.narration, req.user!.id])).rows[0];
    let i = 1; for (const l of b.lines) await c.query("insert into gl_lines (family_id, journal_id, line_no, account_id, debit, credit, narration, sub_ledger_type, sub_ledger_id) values ($1,$2,$3,$4,$5,$6,$7,$8,$9)", [req.family!.familyId, j.id, i++, l.account_id, l.debit, l.credit, l.narration ?? null, l.sub_ledger_type ?? null, l.sub_ledger_id ?? null]);
    return j;   // deferred triggers (balance, period lock) fire at commit; withFamily throws → 409 before any response
  }).then((j) => reply.code(201).send(j)));
  app.get("/gl/periods", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select * from gl_periods where entity_id=$1 order by period_start", [(req.query as any).entity_id])).rows));
  app.post("/gl/periods/:id/status", { preHandler: requireRole("owner", "operator") }, async (req) => withFamily(req.family!.familyId, async (c) => {
    const { id } = req.params as any; const { status } = z.object({ status: z.enum(["open", "soft_closed", "locked"]) }).parse(req.body);
    return (await c.query("update gl_periods set status=$2::period_status, closed_by=case when $2::text='open' then null else $3::uuid end, closed_at=case when $2::text='open' then null else now() end where id=$1 returning *", [id, status, req.user!.id])).rows[0];
  }));

  // ---- action plane (safety-critical paths implemented; connectors/executor are separate services) ----
  app.get("/actions", async (req) => withFamily(req.family!.familyId, async (c) => {
    const q = req.query as any; const params: any[] = []; let w = "where 1=1";
    if (q.status) { params.push(q.status); w += ` and i.status=$${params.length}`; }
    const r = await c.query(`select i.*, e.name as entity_name, u.name as proposed_by_name, (select json_agg(json_build_object('approver_user_id', a.approver_user_id, 'name', au.name, 'decision', a.decision, 'auth_method', a.auth_method, 'decided_at', a.decided_at)) from action_approvals a join users au on au.id=a.approver_user_id where a.intent_id=i.id) as approvals
      from action_intents i join entities e on e.id=i.entity_id left join users u on u.id=i.proposed_by_user_id ${w} order by i.created_at desc limit 200`, params);
    return { items: r.rows, next_cursor: null };
  }));
  app.post("/actions", async (req, reply) => withFamily(req.family!.familyId, async (c) => {
    const b = z.object({ entity_id: z.string().uuid(), kind: z.string(), connector_id: z.string().uuid().optional(), payload: z.record(z.any()), amount: z.coerce.number().positive(), rationale: z.string().optional(), source_type: z.string().optional(), source_id: z.string().uuid().optional(), batch_id: z.string().uuid().optional(), idempotency_key: z.string().optional() }).parse(req.body);
    // policy check: tiers and caps from execution_policies (family defaults if none)
    const pol = (await c.query("select code, params from execution_policies where active and (entity_id is null or entity_id=$1) and (intent_kind is null or intent_kind=$2::intent_kind)", [b.entity_id, b.kind])).rows;
    const checks: any[] = []; let approvers = 1; let cooling: Date | null = null; let fail = false;
    for (const p of pol) {
      if (p.code === "max_single_amount") { const ok = b.amount <= Number(p.params.amount); checks.push({ code: p.code, pass: ok, limit: p.params.amount }); fail ||= !ok; }
      if (p.code === "approvers_required" && (!p.params.above || b.amount > Number(p.params.above))) approvers = Math.max(approvers, Number(p.params.count));
      if (p.code === "cooling_off_minutes" && b.amount > Number(p.params.above ?? 0)) cooling = new Date(Date.now() + Number(p.params.minutes) * 60000);
      if (p.code === "allowed_payees" && b.payload.payee_id) { const v = (await c.query("select 1 from payees where id=$1 and verified_at is not null and active", [b.payload.payee_id])).rowCount; checks.push({ code: p.code, pass: !!v, detail: v ? "verified payee" : "payee unverified" }); fail ||= !v; }
    }
    if (!pol.some((p) => p.code === "max_single_amount")) { const ok = b.amount <= 500000; checks.push({ code: "max_single_amount", pass: ok, limit: "500000 (default)" }); fail ||= !ok; }
    let connectorId = b.connector_id ?? null;
    if (!connectorId) {   // assisted / sandbox route until a real connector is linked
      const m = await c.query("select id from connectors where entity_id=$1 and provider='manual' and revoked_at is null limit 1", [b.entity_id]);
      connectorId = m.rowCount ? m.rows[0].id : (await c.query("insert into connectors (family_id, entity_id, kind, provider, label, status, sandbox, created_by) values ($1,$2,'custom','manual','Assisted / sandbox','sandbox',true,$3) returning id", [req.family!.familyId, b.entity_id, req.user!.id])).rows[0].id;
    }
    const ks = (await c.query("select paused from kill_switches where family_id=$1", [req.family!.familyId])).rows[0];
    checks.push({ code: "kill_switch", pass: !ks?.paused, detail: ks?.paused ? "execution paused" : "running" });
    const r = await c.query(`insert into action_intents (family_id, entity_id, kind, status, connector_id, payload, amount, rationale, proposed_by_kind, proposed_by_user_id, source_type, source_id, policy_result, approvers_required, cooling_off_until, expires_at, batch_id, idempotency_key)
      values ($1,$2,$3::intent_kind,$4::intent_status,$5,$6,$7,$8,'user',$9,$10,$11,$12,$13,$14, now() + interval '24 hours', $15, $16) returning *`,
      [req.family!.familyId, b.entity_id, b.kind, "draft", connectorId, JSON.stringify(b.payload), b.amount, b.rationale ?? null, req.user!.id, b.source_type ?? null, b.source_id ?? null, JSON.stringify(checks), approvers, cooling, b.batch_id ?? null, b.idempotency_key ?? `${req.user!.id}-${Date.now()}-${Math.random()}`]);
    const next = fail ? "policy_failed" : "pending_approval";
    const u = await c.query("update action_intents set status=$2::intent_status where id=$1 returning *", [r.rows[0].id, next]);
    return u.rows[0];
  }).then((row) => reply.code(201).send(row)));
  app.post("/actions/:id/approve", { preHandler: requireRole("owner", "member") }, async (req, reply) => withFamily(req.family!.familyId, async (c) => {
    const { id } = req.params as any; const b = z.object({ auth_method: z.enum(["totp", "biometric", "passkey"]), auth_proof: z.string(), note: z.string().optional() }).parse(req.body);
    if (!(await verifyStepUp(req.user!.id, b.auth_method, b.auth_proof))) return reply.code(403).send({ title: "Step-up failed", status: 403 });
    try {
      await c.query("insert into action_approvals (family_id, intent_id, approver_user_id, decision, note, auth_method, ip, user_agent) values ($1,$2,$3,'approved',$4,$5,$6,$7)", [req.family!.familyId, id, req.user!.id, b.note ?? null, b.auth_method, req.ip, req.headers["user-agent"] ?? null]);
    } catch (e: any) { return reply.code(403).send({ title: e.message, status: 403 }); }
    const it = (await c.query("select approvers_required, (select count(*) from action_approvals a where a.intent_id=$1 and decision='approved') as n from action_intents where id=$1", [id])).rows[0];
    if (Number(it.n) >= Number(it.approvers_required)) {
      await c.query("update action_intents set status='approved' where id=$1", [id]);
      await c.query("savepoint q");
      try { await c.query("update action_intents set status='queued' where id=$1", [id]); await c.query("release savepoint q"); }
      catch { await c.query("rollback to savepoint q"); /* cooling-off or kill switch: stays approved; the scheduler queues it later */ }
    }
    return (await c.query("select * from action_intents where id=$1", [id])).rows[0];
  }));
  app.post("/actions/:id/reject", { preHandler: requireRole("owner", "member") }, async (req) => withFamily(req.family!.familyId, async (c) => {
    const { id } = req.params as any; const b = z.object({ note: z.string().optional() }).parse(req.body ?? {});
    await c.query("insert into action_approvals (family_id, intent_id, approver_user_id, decision, note, auth_method) values ($1,$2,$3,'rejected',$4,'totp') on conflict do nothing", [req.family!.familyId, id, req.user!.id, b.note ?? null]);
    return (await c.query("update action_intents set status='rejected' where id=$1 returning *", [id])).rows[0];
  }));
  app.get("/kill-switch", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select * from kill_switches where family_id=$1", [req.family!.familyId])).rows[0] ?? { paused: false }));
  app.post("/kill-switch", { preHandler: requireRole("owner", "member") }, async (req, reply) => withFamily(req.family!.familyId, async (c) => {
    const b = z.object({ paused: z.boolean(), reason: z.string().optional() }).parse(req.body);
    if (!b.paused && req.family!.role !== "owner") return reply.code(403).send({ title: "Only an owner can resume", status: 403 });
    return (await c.query("insert into kill_switches (family_id, paused, paused_by, paused_at, reason) values ($1,$2,$3,now(),$4) on conflict (family_id) do update set paused=$2, paused_by=$3, paused_at=now(), reason=$4 returning *", [req.family!.familyId, b.paused, req.user!.id, b.reason ?? null])).rows[0];
  }));
  app.get("/connectors", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select id, entity_id, kind, provider, label, account_ref, status, scopes, session_expires_at, sandbox, last_health_at, last_error from connectors where revoked_at is null order by created_at")).rows));
  app.get("/execution-policies", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select * from execution_policies order by code")).rows));
  app.get("/oversight", async (req) => withFamily(req.family!.familyId, async (c) => ({
    pending: (await c.query("select id, kind, amount, entity_id, status, created_at, expires_at from action_intents where status='pending_approval' order by created_at")).rows,
    in_flight: (await c.query("select id, kind, amount, status from action_intents where status in ('approved','queued','submitted','partially_filled')")).rows,
    failed_24h: (await c.query("select id, kind, amount, status from action_intents where status='failed' and updated_at > now()-interval '24 hours'")).rows,
    kill_switch: (await c.query("select * from kill_switches where family_id=$1", [req.family!.familyId])).rows[0] ?? { paused: false },
    connectors: (await c.query("select id, provider, label, status, session_expires_at from connectors where revoked_at is null")).rows,
  })));

  // ---- investment policy, research, rebalancing (reads) ----
  app.get("/policies", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query(`select p.*, (select row_to_json(v) from policy_versions v where v.id=p.current_version_id) as current_version,
      (select row_to_json(x) from (select overall, breaches, warnings, as_of from policy_compliance pc where pc.policy_version_id=p.current_version_id order by as_of desc limit 1) x) as compliance from investment_policies p where deleted_at is null order by scope, name`)).rows));
  app.get("/risk-questionnaires", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select id, name, version, questions, family_id is null as system from risk_questionnaires order by family_id nulls first")).rows));
  app.post("/risk-questionnaires/:id/respond", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { id } = req.params as any; const b = z.object({ entity_id: z.string().uuid().optional(), goal_id: z.string().uuid().optional(), answers: z.record(z.string()) }).parse(req.body);
    const q = (await c.query("select questions, scoring from risk_questionnaires where id=$1", [id])).rows[0];
    const dims: Record<string, number[]> = {};
    for (const qu of q.questions) { const opt = qu.options.find((o: any) => o.label === b.answers[qu.id]); if (opt) (dims[qu.dimension] ??= []).push(opt.score); }
    const dscore = (d: string) => { const a = dims[d] ?? []; return a.length ? (a.reduce((s, x) => s + x, 0) / a.length - 1) / 4 * 100 : 50; };
    const w = q.scoring.weights; const capacity = dscore("capacity"), tolerance = dscore("tolerance"), horizon = dscore("horizon"), knowledge = dscore("knowledge");
    const score = capacity * w.capacity + tolerance * w.tolerance + horizon * w.horizon + knowledge * w.knowledge;
    const band = (v: number) => q.scoring.bands.find((x: any) => v <= x.max)?.profile;
    const order = ["conservative", "moderately_conservative", "moderate", "moderately_aggressive", "aggressive"];
    const profile = order[Math.min(order.indexOf(band(score)), order.indexOf(band(capacity)))];   // capacity caps tolerance
    const r = await c.query("insert into risk_questionnaire_responses (family_id, questionnaire_id, entity_id, goal_id, respondent_user_id, answers, score, capacity_score, tolerance_score, horizon_score, profile) values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) returning id", [req.family!.familyId, id, b.entity_id ?? null, b.goal_id ?? null, req.user!.id, JSON.stringify(b.answers), score, capacity, tolerance, horizon, profile]);
    return { response_id: r.rows[0].id, score: +score.toFixed(1), capacity_score: +capacity.toFixed(1), tolerance_score: +tolerance.toFixed(1), horizon_score: +horizon.toFixed(1), profile, notes: capacity < tolerance ? ["capacity caps tolerance"] : [] };
  }));
  app.get("/research/items", async (req) => withFamily(req.family!.familyId, async (c) => ({ items: (await c.query("select i.id, i.title, i.sender, i.received_at, i.status, s.name as source_name, s.kind as source_kind, (select count(*) from research_recommendations r where r.item_id=i.id) as recommendation_count from research_items i left join research_sources s on s.id=i.source_id order by received_at desc limit 100")).rows, next_cursor: null })));
  app.get("/research/proposals", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select * from investment_proposals where status=coalesce($1, status) order by created_at desc", [(req.query as any).status ?? null])).rows));
  app.get("/funding-needs", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select n.*, e.name as entity_name from funding_needs n join entities e on e.id=n.entity_id where need_date <= current_date + $1::int order by need_date", [Number((req.query as any).days ?? 365)])).rows));
  app.get("/rebalance/runs", async (req) => withFamily(req.family!.familyId, async (c) => (await c.query("select r.*, p.name as program_name from rebalance_runs r join rebalance_programs p on p.id=r.program_id order by run_at desc limit 50")).rows));
}
function fyOf(d: string) { const x = new Date(d); const y = x.getMonth() >= 3 ? x.getFullYear() : x.getFullYear() - 1; return `${y}-${String((y + 1) % 100).padStart(2, "0")}`; }
