import type { FastifyInstance } from "fastify";
import { requireFamily } from "../lib/auth.js";
import { withFamily } from "../lib/db.js";
export default async function routes(app: FastifyInstance) {
  app.addHook("preHandler", requireFamily);
  app.get("/entities", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { rows } = await c.query(`select e.id, e.type, e.name, e.pan_last4, e.tax_regime, e.slab_rate,
      coalesce(json_agg(json_build_object('id', g.id, 'gstin', g.gstin)) filter (where g.id is not null), '[]') as gstins
      from entities e left join entity_gstins g on g.entity_id = e.id where e.deleted_at is null group by e.id order by e.name`);
    return rows;
  }));
  app.get("/members", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { rows } = await c.query(`select u.id as user_id, u.name, u.email, m.role, m.entity_scope from family_members m join users u on u.id = m.user_id where m.family_id = $1 order by m.role, u.name`, [req.family!.familyId]);
    return rows;
  }));
}
