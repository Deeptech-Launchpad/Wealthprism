import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { requireFamily } from "../lib/auth.js";
import { withFamily, money } from "../lib/db.js";
import { bucketDrift, requiredFloat, deployableExcess } from "@fo/finance";

/** Holdings valued at latest price; PMS/AIF/private without a price row are valued at cost. */
const HOLDINGS_SQL = `
  select h.id, h.entity_id, e.name as entity_name, h.bucket, h.quantity, h.avg_cost, h.core_satellite,
         i.id as instrument_id, i.name as instrument, i.type, i.symbol, i.isin, i.asset_class,
         p.close as price, p.price_date,
         round(h.quantity * h.avg_cost, 2) as cost,
         round(h.quantity * coalesce(p.close, h.avg_cost), 2) as value
  from holdings h
  join entities e on e.id = h.entity_id
  join instruments i on i.id = h.instrument_id
  left join lateral (select close, price_date from prices where instrument_id = i.id order by price_date desc limit 1) p on true
  where 1=1`;

const monthsSince = (d: Date | string) => { const b = new Date(d), n = new Date(); return (n.getFullYear() - b.getFullYear()) * 12 + (n.getMonth() - b.getMonth()) - (n.getDate() < b.getDate() ? 1 : 0); };

export default async function routes(app: FastifyInstance) {
  app.addHook("preHandler", requireFamily);

  app.get("/holdings", async (req) => {
    const q = z.object({ entity_id: z.string().uuid().optional(), bucket: z.enum(["liquidity", "income", "growth"]).optional() }).parse(req.query);
    return withFamily(req.family!.familyId, async (c) => {
      const params: any[] = []; let sql = HOLDINGS_SQL;
      if (q.entity_id) { params.push(q.entity_id); sql += ` and h.entity_id = $${params.length}`; }
      if (q.bucket) { params.push(q.bucket); sql += ` and h.bucket = $${params.length}`; }
      const { rows } = await c.query(sql + " order by value desc", params);
      const items = rows.map((r) => ({ ...r, cost: money(r.cost), value: money(r.value), unrealised_gain: money(Number(r.value) - Number(r.cost)), unrealised_gain_pct: Number(r.cost) ? +(((Number(r.value) - Number(r.cost)) / Number(r.cost)) * 100).toFixed(2) : 0 }));
      const totals = { cost: money(items.reduce((s, i) => s + Number(i.cost), 0)), value: money(items.reduce((s, i) => s + Number(i.value), 0)) };
      return { items, totals, next_cursor: null };
    });
  });

  app.get("/holdings/:id/lots", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { id } = req.params as { id: string };
    const { rows } = await c.query("select id, buy_date, quantity, remaining_qty, unit_cost, charges, grandfathered_fmv from lots where holding_id = $1 order by buy_date", [id]);
    return rows.map((l) => ({ ...l, term_now: monthsSince(l.buy_date) >= 12 ? "long" : "short" }));
  }));

  app.get("/properties", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { rows } = await c.query(`
      select p.id, p.type, p.name, p.address, p.acquisition_date, p.acquisition_cost, p.self_occupied,
        (select value from property_valuations v where v.property_id = p.id order by valued_on desc limit 1) as current_value,
        (select valued_on from property_valuations v where v.property_id = p.id order by valued_on desc limit 1) as valued_on,
        (select json_build_object('id', l.id, 'rent', l.rent, 'end_date', l.end_date, 'gst_applicable', l.gst_applicable, 'tds_applicable', l.tds_applicable, 'tenant', t.name)
           from leases l join tenants t on t.id = l.tenant_id where l.property_id = p.id and l.status = 'active' order by l.end_date desc limit 1) as active_lease,
        (select json_agg(json_build_object('entity_id', o.entity_id, 'name', e.name, 'ownership_pct', o.ownership_pct)) from property_owners o join entities e on e.id = o.entity_id where o.property_id = p.id) as owners
      from properties p where p.deleted_at is null order by current_value desc nulls last`);
    return rows.map((p) => {
      const rent = p.active_lease?.rent ? Number(p.active_lease.rent) : 0;
      const gross = p.current_value ? +(((rent * 12) / Number(p.current_value)) * 100).toFixed(2) : null;
      return { ...p, current_value: money(p.current_value), gross_yield_pct: gross };
    });
  }));

  app.get("/rent-schedule", async (req) => {
    const q = z.object({ month: z.string().regex(/^\d{4}-\d{2}$/) }).parse(req.query);
    return withFamily(req.family!.familyId, async (c) => {
      const { rows } = await c.query(`
        select rs.id, rs.lease_id, p.name as property, t.name as tenant, rs.period_month, rs.due_date, rs.expected_rent, rs.expected_gst, rs.expected_tds,
               rs.received_amount, rs.received_on, rs.bank_txn_id, rs.status, greatest(0, (current_date - rs.due_date)) as overdue_days
        from rent_schedule rs join leases l on l.id = rs.lease_id join properties p on p.id = l.property_id join tenants t on t.id = l.tenant_id
        where rs.period_month = ($1 || '-01')::date order by rs.due_date`, [q.month]);
      return rows;
    });
  });

  app.get("/bank-accounts", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { rows } = await c.query(`select b.id, b.entity_id, e.name as entity_name, b.bank, b.account_masked, b.type, b.balance, b.balance_as_of, b.sync_mode, a.expires_on as consent_expires_on
      from bank_accounts b join entities e on e.id = b.entity_id left join aa_consents a on a.id = b.aa_consent_id where b.deleted_at is null order by b.bank`);
    return rows.map((r) => ({ ...r, balance: money(r.balance) }));
  }));

  app.get("/bank-txns", async (req) => {
    const q = z.object({ account_id: z.string().uuid().optional(), limit: z.coerce.number().max(200).default(50) }).parse(req.query);
    return withFamily(req.family!.familyId, async (c) => {
      const params: any[] = [q.limit]; let where = "";
      if (q.account_id) { params.push(q.account_id); where = " where t.bank_account_id = $2"; }
      const { rows } = await c.query(`select t.id, t.bank_account_id, b.bank || ' ' || b.account_masked as account_label, t.txn_date, t.narration, t.amount, cat.name as category, t.category_id, t.link_type, t.link_id
        from bank_txns t join bank_accounts b on b.id = t.bank_account_id left join categories cat on cat.id = t.category_id ${where} order by t.txn_date desc, t.created_at desc limit $1`, params);
      return { items: rows.map((r) => ({ ...r, amount: money(r.amount) })), next_cursor: null };
    });
  });

  app.get("/tasks", async (req) => {
    const q = z.object({ status: z.enum(["open", "done", "dismissed"]).default("open"), module: z.string().optional() }).parse(req.query);
    return withFamily(req.family!.familyId, async (c) => {
      const params: any[] = [q.status]; let extra = "";
      if (q.module) { params.push(q.module); extra = " and module = $2"; }
      const { rows } = await c.query(`select t.*, e.name as entity_name from tasks t left join entities e on e.id = t.entity_id where t.status = $1 ${extra} order by t.severity, t.due_date nulls last`, params);
      return rows.map((r) => ({ ...r, amount: r.amount === null ? null : money(r.amount) }));
    });
  });

  app.patch("/tasks/:id", async (req, reply) => {
    const { id } = req.params as { id: string };
    const body = z.object({ status: z.enum(["open", "done", "dismissed"]).optional(), assignee_user_id: z.string().uuid().optional(), due_date: z.string().optional() }).parse(req.body);
    if (req.family!.role === "viewer") return reply.code(403).send({ title: "Viewers cannot change tasks", status: 403 });
    return withFamily(req.family!.familyId, async (c) => {
      const { rows } = await c.query(`update tasks set status = coalesce($2::task_status, status), assignee_user_id = coalesce($3::uuid, assignee_user_id), due_date = coalesce($4::date, due_date),
        done_at = case when $2 = 'done' then now() else done_at end where id = $1 returning *`, [id, body.status ?? null, body.assignee_user_id ?? null, body.due_date ?? null]);
      if (!rows[0]) return reply.code(404).send({ title: "Not found", status: 404 });
      await c.query("insert into audit_log (family_id, user_id, action, table_name, row_id, after) values ($1,$2,'update','tasks',$3,$4)", [req.family!.familyId, req.user!.id, id, JSON.stringify(body)]);
      return { ...rows[0], amount: rows[0].amount === null ? null : money(rows[0].amount) };
    });
  });

  app.get("/goals", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { rows } = await c.query("select g.*, e.name as entity_name from goals g left join entities e on e.id = g.entity_id order by g.target_year");
    return rows.map((g) => { const yrs = Math.max(0, g.target_year - new Date().getFullYear()); const need = Number(g.amount_today) * Math.pow(1 + Number(g.inflation_pct) / 100, yrs); return { ...g, amount_today: money(g.amount_today), inflated_need: money(need), on_track: Number(g.funded_pct ?? 0) >= Math.min(100, 100 - yrs * 6) }; });
  }));

  async function bucketValues(c: any) {
    const rows = (await c.query(HOLDINGS_SQL)).rows;
    const v: Record<string, number> = { liquidity: 0, income: 0, growth: 0 };
    for (const r of rows) v[r.bucket] += Number(r.value);
    v.income += Number((await c.query("select coalesce(sum((select value from property_valuations v where v.property_id = p.id order by valued_on desc limit 1)),0) as v from properties p where p.deleted_at is null and not p.self_occupied")).rows[0].v);
    v.growth += Number((await c.query("select coalesce(sum(coalesce((select value from private_marks m where m.private_investment_id = pi.id order by marked_on desc limit 1), pi.amount)),0) as v from private_investments pi where pi.status <> 'written_off'")).rows[0].v);
    v.liquidity += Number((await c.query("select coalesce(sum(balance),0) as v from bank_accounts where deleted_at is null and type <> 'card'")).rows[0].v);
    return v as { liquidity: number; income: number; growth: number };
  }

  app.get("/buckets/drift", async (req) => withFamily(req.family!.familyId, async (c) => {
    const v = await bucketValues(c);
    const t = (await c.query("select liquidity_pct, income_pct, growth_pct, drift_threshold_pp from bucket_targets where entity_id is null order by effective_from desc limit 1")).rows[0] ?? { liquidity_pct: 8, income_pct: 32, growth_pct: 60, drift_threshold_pp: 1.5 };
    return bucketDrift(v, { liquidity: +t.liquidity_pct, income: +t.income_pct, growth: +t.growth_pct, driftThresholdPp: +t.drift_threshold_pp }).map((s) => ({ ...s, value: money(s.value) }));
  }));

  app.get("/working-capital/summary", async (req) => withFamily(req.family!.familyId, async (c) => {
    const cash = Number((await c.query("select coalesce(sum(balance),0) v from bank_accounts where deleted_at is null and type in ('savings','current')")).rows[0].v);
    const outflows = (await c.query("select due_date, amount from committed_outflows where status = 'pending' and due_date >= current_date")).rows.map((r: any) => ({ dueDate: new Date(r.due_date).toISOString().slice(0, 10), amount: Number(r.amount) }));
    const s = (await c.query("select float_days, buffer_months, idle_days from wc_settings")).rows[0] ?? { float_days: 60, buffer_months: 1, idle_days: 30 };
    const avg = Number((await c.query("select coalesce(-sum(amount),0)/3 v from bank_txns where amount < 0 and txn_date > current_date - 90 and link_type <> 'transfer'")).rows[0].v);
    const input = { cash, outflows, floatDays: +s.float_days, avgMonthlyOutflow: avg, bufferMonths: +s.buffer_months, asOf: new Date().toISOString().slice(0, 10) };
    const rf = requiredFloat(input), ex = deployableExcess(input);
    return { cash_total: money(cash), required_float: money(rf), float_days: +s.float_days, deployable_excess: money(ex), idle_days: +s.idle_days, drag_per_year: money(ex * 0.045), committed_outflows: outflows.length };
  }));

  app.get("/private-investments", async (req) => withFamily(req.family!.familyId, async (c) => {
    const { rows } = await c.query(`select pi.*, co.name as company, e.name as entity_name,
      (select value from private_marks m where m.private_investment_id = pi.id order by marked_on desc limit 1) as mark,
      (select total_commitment - drawn from fund_commitments f where f.private_investment_id = pi.id) as unfunded
      from private_investments pi join private_companies co on co.id = pi.company_id join entities e on e.id = pi.entity_id order by pi.invested_on`);
    return rows.map((r) => ({ ...r, amount: money(r.amount), mark: money(r.mark ?? r.amount), unfunded: money(r.unfunded), moic: Number(r.amount) ? +(Number(r.mark ?? r.amount) / Number(r.amount)).toFixed(2) : null }));
  }));

  app.get("/dashboard", async (req) => withFamily(req.family!.familyId, async (c) => {
    const holdings = (await c.query(HOLDINGS_SQL)).rows;
    const byEntity: Record<string, { name: string; value: number }> = {};
    for (const r of holdings) { byEntity[r.entity_id] ??= { name: r.entity_name, value: 0 }; byEntity[r.entity_id].value += Number(r.value); }
    const props = (await c.query("select (select value from property_valuations v where v.property_id = p.id order by valued_on desc limit 1) as value, (select entity_id from property_owners o where o.property_id = p.id limit 1) as entity_id from properties p where p.deleted_at is null")).rows;
    for (const p of props) if (byEntity[p.entity_id]) byEntity[p.entity_id].value += Number(p.value ?? 0);
    const priv = (await c.query("select entity_id, coalesce((select value from private_marks m where m.private_investment_id = pi.id order by marked_on desc limit 1), pi.amount) as value from private_investments pi where pi.status <> 'written_off'")).rows;
    for (const p of priv) if (byEntity[p.entity_id]) byEntity[p.entity_id].value += Number(p.value);
    const banks = (await c.query("select entity_id, sum(balance) v, count(*) n, count(*) filter (where sync_mode = 'aa') live from bank_accounts where deleted_at is null group by entity_id")).rows;
    for (const b of banks) if (byEntity[b.entity_id]) byEntity[b.entity_id].value += Number(b.v);
    const netWorth = Object.values(byEntity).reduce((s, e) => s + e.value, 0);
    const rent = (await c.query("select coalesce(sum(expected_rent),0) due, count(*) filter (where status='received') received, count(*) filter (where status='overdue') overdue from rent_schedule where period_month = date_trunc('month', current_date)::date")).rows[0];
    const gains = (await c.query("select coalesce(sum(gain),0) g from realized_gains where fy = '2026-27'")).rows[0];
    const attention = (await c.query("select t.*, e.name as entity_name from tasks t left join entities e on e.id = t.entity_id where t.status = 'open' order by t.severity, t.due_date nulls last limit 5")).rows;
    const v = await bucketValues(c);
    const t = (await c.query("select liquidity_pct, income_pct, growth_pct, drift_threshold_pp from bucket_targets where entity_id is null order by effective_from desc limit 1")).rows[0] ?? { liquidity_pct: 8, income_pct: 32, growth_pct: 60, drift_threshold_pp: 1.5 };
    return {
      net_worth: money(netWorth),
      bank_balance_total: money(banks.reduce((s, b) => s + Number(b.v), 0)), bank_accounts_live: banks.reduce((s, b) => s + Number(b.live), 0), bank_accounts_total: banks.reduce((s, b) => s + Number(b.n), 0),
      rent: { due: money(rent.due), received_count: Number(rent.received), overdue_count: Number(rent.overdue) },
      capital_gains_ytd: money(gains.g),
      buckets: bucketDrift(v, { liquidity: +t.liquidity_pct, income: +t.income_pct, growth: +t.growth_pct, driftThresholdPp: +t.drift_threshold_pp }).map((s) => ({ ...s, value: money(s.value) })),
      by_entity: Object.entries(byEntity).map(([entity_id, e]) => ({ entity_id, name: e.name, net_worth: money(e.value) })),
      attention: attention.map((x) => ({ ...x, amount: x.amount === null ? null : money(x.amount) })),
    };
  }));
}
