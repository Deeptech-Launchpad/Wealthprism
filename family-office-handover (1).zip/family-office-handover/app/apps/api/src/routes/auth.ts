import type { FastifyInstance } from "fastify";
import jwt from "jsonwebtoken";
import { z } from "zod";
import { verifyPassword, issueTokens, familiesFor } from "../lib/auth.js";
import { pool } from "../lib/db.js";
import { config } from "../config.js";
export default async function routes(app: FastifyInstance) {
  app.post("/auth/login", { config: { rateLimit: { max: 10, timeWindow: "1 minute" } } }, async (req, reply) => {
    const body = z.object({ email: z.string().email(), password: z.string().min(1) }).parse(req.body);
    const user = await verifyPassword(body.email, body.password);
    if (!user) return reply.code(401).send({ title: "Invalid credentials", status: 401 });
    await pool.query("update users set last_login_at = now() where id = $1", [user.id]);
    return { ...issueTokens(user), user, families: await familiesFor(user.id) };
  });
  app.post("/auth/refresh", async (req, reply) => {
    const body = z.object({ refresh_token: z.string() }).parse(req.body);
    try {
      const p: any = jwt.verify(body.refresh_token, config.refreshSecret);
      const { rows } = await pool.query("select id, email, name from users where id = $1", [p.sub]);
      if (!rows[0]) throw new Error();
      return { ...issueTokens(rows[0]), families: await familiesFor(rows[0].id) };
    } catch { return reply.code(401).send({ title: "Invalid refresh token", status: 401 }); }
  });
}
