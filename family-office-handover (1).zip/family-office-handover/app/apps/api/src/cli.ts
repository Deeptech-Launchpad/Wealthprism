import bcrypt from "bcryptjs";
import { pool } from "./lib/db.js";
const [cmd, ...rest] = process.argv.slice(2);
const arg = (k: string) => { const i = rest.indexOf(`--${k}`); return i >= 0 ? rest[i + 1] : undefined; };
if (cmd === "set-password") { await pool.query("update users set password_hash=$2 where email=$1", [arg("email"), await bcrypt.hash(arg("password")!, 10)]); console.log("password set"); }
else if (cmd === "create-owner") {
  const pw = arg("password") ?? Math.random().toString(36).slice(2, 12) + "!A1";
  const fam = await pool.query("insert into families (name) values ($1) returning id", [arg("family") ?? "My Family"]);
  const u = await pool.query("insert into users (email, name, password_hash) values ($1,$2,$3) returning id", [arg("email"), arg("name") ?? "Owner", await bcrypt.hash(pw, 10)]);
  await pool.query("insert into family_members (family_id, user_id, role, accepted_at) values ($1,$2,'owner',now())", [fam.rows[0].id, u.rows[0].id]);
  console.log(JSON.stringify({ family_id: fam.rows[0].id, user_id: u.rows[0].id, one_time_password: pw }));
} else console.log("usage: cli set-password --email x --password y | create-owner --email x --name n [--family f]");
await pool.end();
