import Fastify from "fastify";
import cors from "@fastify/cors";
import { ZodError } from "zod";
import { config } from "./config.js";
import authRoutes from "./routes/auth.js";
import familyRoutes from "./routes/family.js";
import portfolioRoutes from "./routes/portfolio.js";
import moduleRoutes from "./routes/modules.js";
import importRoutes from "./routes/imports.js";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import multipart from "@fastify/multipart";
import { registerStubs } from "./lib/stubs.js";
import { existsSync } from "node:fs";
import { pool } from "./lib/db.js";

export function buildApp() {
  const app = Fastify({ logger: { level: process.env.LOG_LEVEL ?? "info" } });
  app.register(cors, { origin: config.corsOrigin === "*" ? true : config.corsOrigin.split(","), allowedHeaders: ["Authorization", "Content-Type", "X-Family-Id"] });
  app.register(helmet, { contentSecurityPolicy: false });
  app.register(rateLimit, { max: Number(process.env.RATE_LIMIT_MAX ?? 300), timeWindow: "1 minute", allowList: (req) => req.url === "/healthz" || req.url === "/readyz" });
  app.register(multipart, { limits: { fileSize: 25 * 1024 * 1024, files: 1 } });
  app.setErrorHandler((err: any, _req, reply) => {
    if (err instanceof ZodError) return reply.code(422).send({ title: "Validation failed", status: 422, errors: err.issues });
    const status = err.statusCode ?? 500;
    if (status >= 500) app.log.error(err);
    reply.code(status).send({ title: err.message ?? "Error", status });
  });
  app.get("/healthz", async () => ({ ok: true }));
  app.get("/readyz", async () => { await pool.query("select 1"); return { ok: true }; });
  app.register(authRoutes, { prefix: "/api/v1" });
  app.register(familyRoutes, { prefix: "/api/v1" });
  app.register(portfolioRoutes, { prefix: "/api/v1" });
  app.register(moduleRoutes, { prefix: "/api/v1" });
  app.register(importRoutes, { prefix: "/api/v1" });
  const spec = [process.env.OPENAPI_PATH, new URL("../../../../api/openapi.yaml", import.meta.url).pathname, "/api/openapi.yaml"].find((p) => p && existsSync(p));
  if (spec) app.register(async (a) => { await a.after(); registerStubs(app, spec); });
  return app;
}
const entry = process.argv[1] ?? "";
if (entry.endsWith("server.ts") || entry.endsWith("server.js")) {
  const app = buildApp();
  app.listen({ port: config.port, host: "0.0.0.0" }).then(() => app.log.info(`listening on :${config.port}`));
}
