export const config = {
  port: Number(process.env.PORT ?? 4000),
  databaseUrl: process.env.DATABASE_URL ?? "postgres://app_user:app@localhost:5432/familyoffice",
  migrationDatabaseUrl: process.env.MIGRATION_DATABASE_URL ?? process.env.DATABASE_URL ?? "postgres://postgres:postgres@localhost:5432/familyoffice",
  jwtSecret: process.env.JWT_SECRET ?? "dev-only-change-me",
  refreshSecret: process.env.REFRESH_SECRET ?? "dev-only-change-me-too",
  accessTtl: 900,
  refreshTtl: 60 * 60 * 24 * 30,
  corsOrigin: process.env.CORS_ORIGIN ?? "*",
  dbDir: process.env.DB_DIR ?? new URL("../../../../db", import.meta.url).pathname,
};
