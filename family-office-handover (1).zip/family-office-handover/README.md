# Family Office — complete handover

One bundle: specification, verified database and API contract, clickable prototype, the runnable application (web + mobile + API + engines),
Docker deployment for any VPS, and the developer setup. Word versions of every guide are in `docx/`.

## Read in this order

| # | File | What it is |
|---|---|---|
| 1 | `VPS-DEPLOYMENT.md` | Deploy on a VPS with one script (`deploy/bootstrap-vps.sh`), day-2 operations, porting to another server, and every error met on the first deployment with its fix |
| 2 | `DEV-SETUP.md` | Run it on a laptop in ten minutes (infra in Docker, code with hot reload) |
| 3 | `BUILD-STATUS.md` | Exactly what is implemented and verified, and which ticket adds each remaining piece |
| 4 | `family-office-PRD.md` | The specification (v2.0): 21 modules, schema, API, calculations, acceptance tests, decisions |
| 5 | `family-office-prototype.html` | Clickable reference UI for every screen (toggle Web/Mobile at the top) |
| 6 | `tickets/phases_0-2_tickets.md` / `.csv` | 130 tickets with acceptance criteria and dependencies; CSV imports into Jira/Linear |
| 7 | `family-office-BENCHMARK.md`, `family-office-EXECUTION-ROUTES.md` | Why each feature exists; how MF and bank execution actually connect in India |

## Layout

```
app/            monorepo: apps/api (Fastify), apps/worker (in api), apps/executor, apps/web (React 19), apps/mobile (Expo), packages/finance; app/deploy/*.Dockerfile; CI
db/             SQL migrations 001–013 (schema, RLS, GL invariants, action-plane state machine) + seeds; applied automatically on first Postgres start
api/            openapi.yaml — 231 paths; unimplemented ones answer 501 with the ticket name
deploy/         docker-compose.yml (+ dev overlay), .env.example / .env.dev, bootstrap-vps.sh, caddy/, nginx/, scripts/ (backup, restore, deploy)
samples/        parser fixtures (CAS, contract notes, bank CSV, AA JSON, 26AS, PMS)
docx/           Word versions of all guides
```

## Quick start

```bash
# a VPS
DOMAIN=app.example.in EMAIL=you@example.in bash deploy/bootstrap-vps.sh
# a laptop
cd deploy && docker compose -f docker-compose.yml -f docker-compose.dev.yml --env-file .env.dev up -d postgres redis minio && cd ../app && pnpm install && pnpm --filter @fo/finance build && pnpm dev:api & pnpm dev:web
```
Demo login (seeded environments only): `arjun@example.com` / `Prototype!2026`.

Source of truth once cloned: your Git repository. Deploy a new version with `git pull && docker compose build && docker compose up -d`.
