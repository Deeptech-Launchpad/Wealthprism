# Deploying Family Office on your own VPS

Everything runs in Docker from this repository; the only host-level piece is the public edge (TLS). This guide is the
exact sequence that produced the running production instance, including every problem met on the way and its fix.

## 1. What you need

- A VPS with Ubuntu 22.04 or 24.04, 2 vCPU / 8 GB RAM / 40 GB disk or more (Hostinger KVM 2 is fine), root or sudo user.
- A domain or subdomain pointed at the VPS (A record → VPS IPv4). Optional for a first run; required for HTTPS.
- This repository (clone from GitHub or extract the handover zip).

## 2. One-shot deployment

```bash
git clone https://github.com/<owner>/familyoffice.git && cd familyoffice      # or: unzip family-office-handover.zip && cd handover
DOMAIN=app.example.in EMAIL=you@example.in bash deploy/bootstrap-vps.sh
```
Add `SEED=true` for a staging box that should load the demo family (`arjun@example.com` / `Prototype!2026`). Never on production.

The script installs Docker (and `gh` if you pass `GH_OWNER` to create/push a GitHub repo), generates `deploy/.env` with random secrets,
detects whether port 80 is free, sets the Caddy site address, builds the four images, starts the stack and checks `/healthz`.

- **Fresh VPS, port 80 free** → Caddy serves the site directly; with `DOMAIN` set it obtains a Let's Encrypt certificate on first request. Done.
- **Port 80 already used** (another site on nginx/Apache) → Caddy binds `127.0.0.1:8080`; the script prints an nginx server block and the certbot
  command to put your domain in front of it. Copy-paste those, and you are done.

## 3. What runs

| Service | Image | Role |
|---|---|---|
| caddy | caddy:2-alpine | reverse proxy: `/api/*` → api, everything else → web; TLS when it owns 80/443 |
| web | built from `app/deploy/web.Dockerfile` | React app served by nginx |
| api | built from `app/deploy/api.Dockerfile` | Fastify API on :4000, `/healthz`, `/readyz` |
| worker | same image, `dist/worker.js` | scheduler: expiring intents, cooling-off release, overdue rent, GL balance refresh |
| executor | `app/deploy/executor.Dockerfile` | execution loop on its own DB role; sandbox until `SANDBOX_ONLY=false` |
| postgres | postgres:16-alpine | applies `db/001…013` on first start (`deploy/scripts/pg-init.sh`); seeds if `SEED_ON_START=true` |
| redis, minio, backup | redis:7, quay.io/minio/minio, postgres:16 | queue store, documents, nightly dump + rclone offsite |

Data lives in Docker volumes `pg_data`, `minio_data`, `redis_data`, `backups`, `caddy_data`.

## 4. Day-2 operations

```bash
cd deploy
sudo docker compose ps                        # status
sudo docker compose logs -f api               # logs (worker, executor, caddy, postgres likewise)
git pull && sudo docker compose build && sudo docker compose up -d     # deploy a new version
sudo docker compose exec api node dist/cli.js create-owner --email you@x.in --name "Name" --family "Family"   # first real user
sudo docker compose exec api node dist/cli.js set-password --email you@x.in --password 'NewPass!'
./scripts/backup.sh                           # manual backup; nightly runs automatically in the backup container
./scripts/restore.sh /backups/<stamp>         # restore
```
Reset a staging database to the seed: `sudo docker compose down -v postgres && sudo docker compose up -d postgres`.

## 5. Porting to another VPS

1. On the old server: `cd deploy && ./scripts/backup.sh` and copy the newest `/backups/<stamp>` directory off the box
   (`sudo docker cp familyoffice-backup-1:/backups/<stamp> ./`).
2. On the new server: clone the repo, copy the old `deploy/.env` (same secrets, or the field-encryption key must match),
   run `DOMAIN=… bash deploy/bootstrap-vps.sh`, then `docker compose stop api worker` and `./scripts/restore.sh <dir>`, then `up -d`.
3. Switch DNS. Nothing is host-specific.

## 6. Troubleshooting — every error met during the first deployment

| Symptom | Cause | Fix |
|---|---|---|
| `unzip: command not found` | fresh Ubuntu | `sudo apt install -y unzip` |
| `git init` created a repo in `$HOME` and staged other projects | ran before `cd` into the extracted folder | `rm -rf ~/.git`, then `cd handover` and re-run |
| `gh repo create`: "Name already exists" | repo pre-created on GitHub | bootstrap now falls back to `git remote add … && git push --force` |
| Docker build: `COPY apps/web: not found`, `lstat deploy/api: no such file` | compose pointed at old Dockerfiles / wrong context | compose builds from `../app` with `app/deploy/*.Dockerfile` (fixed in repo) |
| `dockerfile parse error … unknown instruction` | a sed edit left a fragment line | Dockerfiles are now written whole; do not patch with sed |
| pnpm: `ERR_PNPM_IGNORED_BUILDS … esbuild` | pnpm 12 refuses postinstall scripts non-interactively | `pnpm install … --dangerously-allow-all-builds` (in the Dockerfiles) |
| `pull access denied for minio/minio` | Docker Hub anonymous pull denied | image is `quay.io/minio/minio:latest` |
| api/worker restarting: `Cannot find module /repo/apps/api/apps/api/dist/server.js` | doubled path | commands are `node dist/server.js` / `dist/worker.js` (fixed) |
| caddy restarting: `server block without any key is global configuration` | empty site address placeholder | Caddyfile site block is `:80 {` or `your.domain {` (bootstrap sets it) |
| caddy: `failed to bind host port 0.0.0.0:80: address already in use` | nginx/Apache on the host | bootstrap detects this and binds Caddy to `127.0.0.1:8080`; put nginx in front |
| Browser: blank page, console `Minified React error #527` | `react` and `react-dom` resolved to different versions | both pinned to `19.0.0` in `app/apps/web/package.json` and the lockfile |
| Browser: `DNS_PROBE_FINISHED_NXDOMAIN` for `1.2.3.4.com` | Chrome appended `.com` to a bare IP | type `http://` before the IP |
| `curl localhost:8080` empty while containers "Up" | Caddy still in restart back-off after config change | `sudo docker compose restart caddy` |
| `Permission denied` on `pnpm-lock.yaml` after running pnpm in a container | file written as root | `sudo chown $USER:$USER app/pnpm-lock.yaml` |
| Domain shows a different site | no nginx server block for that hostname, default site answered | add the server block for the exact hostname(s) and reload nginx |
| certbot: "existing certificate contains a portion of the domains" | expanding an earlier cert | add `--expand` |
| nginx config contains `[www.…](https://…)` | chat/markdown client rewrote the pasted text | retype the line; see `deploy/nginx/wealthprism.conf` for the clean version |
| Browser times out on a port that works with `curl` on the VPS | provider firewall | hPanel → VPS → Firewall → allow the port, or route via nginx on 80/443 |

## 7. Security checklist before real data

- `SEED_ON_START=false`, database reset, first owner created via the CLI, MFA enrolled.
- HTTPS on (Caddy or nginx + certbot); port 8080 bound to `127.0.0.1` when behind nginx.
- Provider firewall: only 22, 80, 443 open. `deploy/.env` never committed (it is git-ignored); keep an offline copy of `FIELD_ENCRYPTION_KEY`.
- `RCLONE_REMOTE` set so nightly backups leave the box; test `scripts/restore.sh` on a staging server.
- `SANDBOX_ONLY=true` stays until each connector passes its dry run (PRD 3.18).
