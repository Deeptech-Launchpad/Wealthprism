# Build status — implemented vs remaining

Generated 12 September 2026 against PRD v2.0 (130 tickets). The runnable code is in `app/`. Verification: 10 finance tests, 13 API integration tests, executor and worker run against the seeded database, web build and mobile type-check — all green.

## Implemented and verified

| Area | What works | Verified by |
|---|---|---|
| Database | Full migration chain `db/001`–`013` applied by `apps/api/src/migrate.ts` (idempotent via `schema_migrations`); seed loads the Mehta family and sets dev passwords | Applied on Postgres 16 |
| Auth & tenancy | bcrypt login, JWT access + rotating refresh, `X-Family-Id` membership via `user_families()` (security definer), per-request `set_config('app.family_id')` in a transaction, roles (viewer cannot write), audit rows on writes | 6 API integration tests: 401 without token, 403 for a non-member family, viewer refused, audit |
| Finance engine | XIRR (Newton + bisection), FIFO lots, bonus/split, capital gains with term, 31-Jan-2018 grandfathering and LTCG exemption, bucket drift, working-capital float/excess, post-tax yield | 10 unit tests |
| API — portfolio | `/auth/login`, `/auth/refresh`, `/entities`, `/members`, `/dashboard`, `/holdings`, `/holdings/:id/lots`, `/properties`, `/rent-schedule`, `/bank-accounts`, `/bank-txns`, `/tasks` (GET/PATCH), `/goals`, `/buckets/drift`, `/working-capital/summary`, `/private-investments`, `/healthz`, `/readyz` | All 200 on seeded data; dashboard aggregates holdings + property + private + cash per entity |
| API — action plane | `POST /actions` (policy check: single-amount cap, approver tiers, cooling-off, payee allow-list, kill switch → `pending_approval` or `policy_failed`), `POST /actions/:id/approve` (step-up TOTP with dev bypass `000000`, role owner/member, four-eyes enforced by DB, N-of-M, queues when threshold met), `/actions/:id/reject`, `GET /actions`, `GET/POST /kill-switch` (member pauses, only owner resumes), `/connectors`, `/execution-policies`, `/oversight` | Tests: operator cannot approve own intent, wrong code refused, cap → policy_failed, kill-switch role rules |
| API — general ledger | `PUT /gl/books` (copies the 84-account CoA template, opens FY periods), `GET /gl/accounts` (with balances), `GET/POST /gl/journals` (deferred balance trigger → 4xx/5xx on unbalanced), `GET /gl/reports/trial-balance`, `GET /gl/periods`, `POST /gl/periods/:id/status` (locked periods reject postings) | Tests: balanced journal posts, TB balances, unbalanced rejected, locked period rejected, viewer refused |
| API — other modules | `/plans`, `/plans/:id`, `/tax/suggestions`, `/policies`, `/risk-questionnaires` (+`:id/respond` with capacity-caps-tolerance scoring), `/research/items`, `/research/proposals`, `/funding-needs`, `/rebalance/runs` (reads); **every remaining OpenAPI path answers 501** naming the ticket, so clients can integrate against the full contract now | Tests: 4 scenarios, 5 suggestions, questionnaire profile, 501 stub |
| Executor | `apps/executor`: separate process on the `executor_user` DB role; polls `queued` intents per family with RLS context, honours the kill switch, idempotent `action_executions`, sandbox adapter (`SANDBOX_ONLY=true`); live provider adapters are FO-124..127 | Filled the test intent with `SBX-…` reference |
| Worker | `apps/api/src/worker.ts`: expires stale intents, releases approved intents after cooling-off, flags overdue rent and raises tasks, refreshes `gl_balances` (60 s) | Ran a tick |
| CLI | `create-owner`, `set-password` | |
| Web app (React 19 + Vite) | Login, shell with family switcher, Dashboard, Investments (lots on click), Real estate (properties + rent schedule), Startups, Goals & buckets (live drift), Banking, Working capital, Tasks (done / dismiss / reopen), **Action plane** (propose, approve with step-up, reject, oversight, kill switch), **Books** (open books per entity, trial balance, day book, lock/reopen periods) | `vite build` type-checks; headless-browser walkthrough with screenshots |
| Mobile app (Expo) | Login, Dashboard, Holdings, Property + rent, **Approvals** (biometric step-up → approve/reject, kill switch), Tasks with biometric step-up, More; SecureStore tokens; silent refresh on 401 | `tsc --noEmit` clean against Expo/RN types (device run not possible here) |
| Deployment | Monorepo Dockerfiles for api and web (executor placeholder), compose wired to `app/` with the migrate one-shot, GitHub Actions CI running all of the above | Compose YAML validates |

## Remaining (ticket map)

| Module | Tickets | Starting point |
|---|---|---|
| Importers (CAS, contract notes, bank CSV, 26AS, e-CAS), email ingest, mapping assistant | FO-27..30 | `samples/` fixtures; `import_jobs` table |
| Price feeds (AMFI, NSE), corporate-actions feed, daily valuations, TWR | FO-20, 21, 32, 38, 95 | `prices`, `valuations_daily` |
| Capital-gains API and Schedule CG export | FO-33, 34 | engine in `packages/finance/capitalGains.ts` |
| Banking: Account Aggregator, categorisation, reconciliation, cash flow | FO-51..54 | `bank_txns`, `categorisation_rules` |
| Task generators, notifications, push | FO-55, 56, 59 | tasks CRUD exists |
| Real estate write paths, GST register, TDS/26AS, property tax, maintenance | phase 3 | read endpoints exist |
| Goals/buckets write paths, model portfolios, asset-class lens | FO-44, 45 | read endpoints exist |
| Planning & taxation engine, scenarios, optimiser | FO-70..81 | seeded scenarios in `db/004` |
| Action plane — live connectors (Kite, BSE StAR MF, ICICI CIB, BBPS), Vault, assistant (Claude) with `propose_intent`, anomaly signals, batch approvals, scheduled intents | FO-121 (full policy set), 122 (passkeys/biometric assertions), 124–134, 128, 131 | Intent model, approvals, executor loop and sandbox adapter exist |
| GL — auto-posting rules engine, opening balances, inter-entity, year-end close, statements beyond TB, Tally sync | FO-47, 62, 63, 110–119 | Books, CoA, manual journals, TB and periods exist |
| Investment Policy builder/compliance, rebalancing solver, research pipeline, balance sheet, analytics, open data | FO-140–166, 90–104 | Schemas, contract, prototype screens, questionnaire scorer; the rest answers 501 |
| Reports (PDF/Excel), documents/MinIO, report packs | FO-33, 103, 115, 146 | |

## Extending — the pattern every ticket follows
1. Add the endpoint to `api/openapi.yaml`.
2. Put the calculation in `packages/finance` with a test.
3. Implement the route in `apps/api/src/routes/*.ts` inside `withFamily()`; add an integration test in `apps/api/test`.
4. Add the web page (copy `Dashboard.tsx`) and the mobile screen (copy `Tasks.tsx`); both use the same client helpers.
