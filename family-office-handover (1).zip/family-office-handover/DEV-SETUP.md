# Developer setup — Family Office

Everything a developer needs is in this repository. Two ways to run it.

## Option A — infrastructure in Docker, code with hot reload (recommended for development)

Prerequisites: Docker Desktop, Node 22, pnpm 12 (`corepack enable && corepack prepare pnpm@12.4.1 --activate`).

```bash
git clone https://github.com/vellayan-code/familyoffice.git && cd familyoffice

# 1. Database (auto-applies db/001–013 and loads the demo family), Redis, MinIO
cd deploy && docker compose -f docker-compose.yml -f docker-compose.dev.yml --env-file .env.dev up -d postgres redis minio && cd ..

# 2. Install and build the shared engine
cd app && pnpm install && pnpm --filter @fo/finance build

# 3. Run the API, worker, executor and web (separate terminals)
DATABASE_URL=postgres://app_user:app@localhost:5432/familyoffice pnpm dev:api                     # http://localhost:4000
DATABASE_URL=postgres://app_user:app@localhost:5432/familyoffice pnpm --filter @fo/api worker
DATABASE_URL=postgres://executor_user:exec@localhost:5432/familyoffice SANDBOX_ONLY=true pnpm --filter @fo/executor dev
pnpm dev:web                                                                                      # http://localhost:5173 (proxies /api → :4000)

# 4. Mobile
cd apps/mobile && pnpm start     # Expo; set extra.apiUrl in app.json to http://<your-lan-ip>:4000/api/v1
```

Sign in as `arjun@example.com` / `Prototype!2026` (also priya, ops, ca). Dev step-up code for approvals: `000000`.

Tests: `pnpm --filter @fo/finance test` · `DATABASE_URL=… pnpm --filter @fo/api test` · `pnpm --filter @fo/web build` · `pnpm --filter @fo/mobile typecheck`.

Reset the database to the seed: `cd deploy && docker compose down -v postgres && docker compose … up -d postgres`.

## Option B — the whole stack in Docker exactly as production

```bash
cd deploy && cp .env.dev .env && docker compose build && docker compose up -d
```
Then open http://localhost (Caddy on port 80 in this mode; on the VPS it is bound to 127.0.0.1:8080 behind nginx). No hot reload; rebuild with `docker compose build <service>` after changes.

## What is where

| Path | Purpose |
|---|---|
| `db/*.sql` | Schema and seed migrations, applied in order on first Postgres start |
| `api/openapi.yaml` | The API contract; unimplemented paths answer 501 with the ticket name |
| `app/apps/api`, `app/apps/web`, `app/apps/mobile`, `app/apps/executor`, `app/packages/finance` | The code |
| `deploy/` | Compose files, Dockerfiles (under `app/deploy`), Caddy, nginx edge config, VPS bootstrap |
| `family-office-PRD.md`, `tickets/`, `BUILD-STATUS.md` | Spec, backlog, what is done |

## Production (for reference)

Hostinger VPS, everything in Docker via `deploy/docker-compose.yml`; nginx on the host terminates TLS for wealthprism.in (`deploy/nginx/wealthprism.conf`) and proxies to Caddy on 127.0.0.1:8080. Deploy after merging to main: `cd ~/handover/deploy && git pull && sudo docker compose build && sudo docker compose up -d`.
